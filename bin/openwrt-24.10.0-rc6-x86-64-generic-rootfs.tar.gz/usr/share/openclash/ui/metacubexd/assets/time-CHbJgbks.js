import{W as a,b4 as m}from"./index-Csmv4Fkv.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
