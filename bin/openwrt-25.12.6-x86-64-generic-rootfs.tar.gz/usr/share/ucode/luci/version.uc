export const revision = '26.326.69129~cb87fe6', branch = 'LuCI openwrt-25.12 branch';
