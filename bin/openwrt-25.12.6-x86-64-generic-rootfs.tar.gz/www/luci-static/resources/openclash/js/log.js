// Extracted from luasrc/view/openclash/log.htm - edit this file, not the template.
// <%:Message%> markers and <%=...%> islands are compiled server-side by the "openclash/translate_js" controller action.

var r;
var s;
var log_len = 0;
var lv = document.getElementById('cbid.openclash.config.clog');
var cl = document.getElementById('core_log');
var dl = document.getElementById('debug_log');
var animatingOC = false;
var animatingCore = false;
var animatingDebug = false;
var coreWebSocket = null;
var coreLogBuffer = [];
var currentLogLevel = 'info';
var wsRetryDelay = 2000;
var wsRetryTimer = null;
var isPolling = false;
var core_refresh = true;
var wsHasData = false;
var coreEditorInitialized = false;
var editor_oc;
var editor_core;
var editor_debug;
var coreLogAccumulator = '';
var coreLogLines = [];
var logMaxLines = 5000;
var pollInterval = 1000;
var debugRenderToken = 0;
// LF-normalized copy of the source the debug view currently shows (textarea values drop CR)
var debugRenderedSrc = '';
var tabPanes = document.getElementsByClassName('dom');
var activeTabPane = -1;
activateTabPane(0);

function accumulateCoreLog(linesArr) {
    var reversed = linesArr.slice().reverse();
    if (coreLogLines.length > 0 && reversed.length > 0 && reversed[reversed.length - 1] === coreLogLines[0]) {
        reversed.pop();
    }
    if (reversed.length > 0) {
        coreLogLines = reversed.concat(coreLogLines);
    }
    if (coreLogLines.length > logMaxLines) {
        coreLogLines = coreLogLines.slice(0, logMaxLines - 1);
        coreLogLines.push('...');
    }
    coreLogAccumulator = coreLogLines.join('\n');
    cl.value = coreLogAccumulator;
}

function setLogTab(log_level) {
    var radio = document.getElementsByName("radios");
    for (i=0; i<radio.length; i++) {
        if (radio[i].value == log_level && ! radio[i].checked) {
            radio[i].checked = true;
        }
    }
};

function get_log_level() {
    XHR.get('<%=url("admin", "services", "openclash", "log_level")%>', null, function(x, status) {
        if (x && x.status == 200 && status.log_level != "") {
            currentLogLevel = status.log_level;
            setLogTab(currentLogLevel);
            coreLogWebSocket();
        }
    });
};

function switch_log_level(value)
{
    if (!coreWebSocket || coreWebSocket.readyState !== WebSocket.OPEN) {
        XHR.get('<%=url("admin", "services", "openclash", "switch_log")%>', {log_level: value}, function(x, status) {
            if (!x || x.status != 200) {
                ocToast(' <%:Log Level%>: ' + value + ' <%:switching failed!%>', 'error');
                return
            }
        });
    }

    currentLogLevel = value;
    setLogTab(currentLogLevel);
    coreLogWebSocket();
};

function stop_refresh() {
    clearTimeout(r);
    coreLogWebSocketStop();
    return
};

function start_refresh() {
    clearTimeout(r);
    coreLogWebSocket();
    r=setTimeout("poll_log()",1000);
    return
};

function toggle_refresh(btn) {
    var paused = btn.dataset.paused === '1';
    if (paused) start_refresh(); else stop_refresh();
    setRefreshButton(btn, !paused);
    return false;
};

function setRefreshButton(btn, paused) {
    btn.dataset.paused = paused ? '1' : '0';
    var use = btn.querySelector('use');
    if (use) use.setAttribute('href', paused ? '#oc-icon-player-play' : '#oc-icon-player-pause');
    var span = btn.querySelector('span');
    if (span) span.textContent = paused ? '<%:Start Refresh%>' : '<%:Stop Refresh%>';
    btn.classList.toggle('active', paused);
};

function createAndDownloadFile(fileName, content) {
    var aTag = document.createElement('a');
    var blob = new Blob([content]);
    aTag.download = fileName;
    aTag.href = URL.createObjectURL(blob);
    aTag.click();
    URL.revokeObjectURL(blob);
};

function download_log(){
    var dt = new Date();
    var timestamp = dt.getFullYear()+"-"+(dt.getMonth()+1)+"-"+dt.getDate()+"-"+dt.getHours()+"-"+dt.getMinutes()+"-"+dt.getSeconds();

    var activeTabId = 0;
    var titles = document.getElementsByName('tab-header');
    for(var i=0; i<titles.length; i++){
        if(titles[i].className === 'oc-tab') {
            activeTabId = i;
            break;
        }
    }

    var downloadContent = "";

    if (activeTabId === 2) {
        var debug_content = dl.value || '';
        if (!debug_content.trim()) return;
        downloadContent += debug_content;
        createAndDownloadFile("OpenClash-Debug-"+timestamp+".log", downloadContent);
        return;
    }

    var oc_content = "";
    if (typeof editor_oc !== 'undefined' && editor_oc) {
        oc_content = editor_oc.getValue();
    } else if (lv && lv.value) {
        oc_content = lv.value;
    } else if (lv && lv.innerHTML) {
        oc_content = lv.innerHTML;
    }

    oc_content = oc_content.split('\n').filter(function(line) {
        return line.indexOf("】" + '<%:Downloading URL%>' + "【") === -1;
    }).join('\n');

    var core_content = "";
    if (typeof editor_core !== 'undefined' && editor_core) {
        core_content = editor_core.getValue();
    } else if (cl && cl.value) {
        core_content = cl.value;
    } else if (cl && cl.innerHTML) {
        core_content = cl.innerHTML;
    }

    if (!oc_content.trim() && !core_content.trim()) {
        return;
    }

    if (oc_content.trim()) {
        downloadContent += "" + '<%:Plugin Logs%>' + ":\n" + oc_content + "\n\n";
    }
    if (core_content.trim()) {
        downloadContent += "" + '<%:Core Logs%>' + ":\n" + core_content;
    }

    createAndDownloadFile("OpenClash-"+timestamp+".log", downloadContent);
    return;
};

function restoreDebugEditor() {
    var wrapper = document.getElementById('debug-render-wrapper');
    var rendered = document.getElementById('debug-rendered');
    if (wrapper) { wrapper.style.display = 'none'; }
    if (rendered) { rendered.innerHTML = ''; }
    debugRenderToken++;
    debugRenderedSrc = '';
    dl.value = "";
    if (typeof editor_debug !== 'undefined' && editor_debug) {
        editor_debug.setValue("");
        if (editor_debug.dom) {
            editor_debug.dom.style.setProperty('display', '', 'important');
        }
        editor_debug.refresh();
    }
}

function del_log() {
    var activeTabId = 0;
    var titles = document.getElementsByName('tab-header');
    for(var i=0; i<titles.length; i++){
        if(titles[i].className === 'oc-tab') {
            activeTabId = i;
            break;
        }
    }

    if (activeTabId === 2) {
        restoreDebugEditor();
        XHR.get('<%=url("admin", "services", "openclash", "del_log")%>', {type: "debug"}, function(x, data){
            ensureDebugEditor();
        });
    } else {
        XHR.get('<%=url("admin", "services", "openclash", "del_log")%>', null, function(x, data){
            lv.value = "";
            cl.value = "";
            coreLogBuffer = [];
            coreLogAccumulator = '';
            coreLogLines = [];
            log_len = 0;
            if (typeof editor_oc !== 'undefined' && editor_oc) {
                editor_oc.setValue(lv.value);
            }
            if (typeof editor_core !== 'undefined' && editor_core) {
                editor_core.setValue(cl.value);
            }
        });
    }
    return
};

function getWebSocketConnectionInfo(callback) {
    XHR.get('<%=url("admin", "services", "openclash", "conn_status")%>', null, function(x, status) {
        if (x && x.status == 200 && status) {
            callback(status);
        } else {
            callback(null);
        }
    });
}

function coreLogWebSocketStop() {
    if (wsRetryTimer) {
        clearTimeout(wsRetryTimer);
        wsRetryTimer = null;
    }

    var ws = coreWebSocket;
    coreWebSocket = null;

    if (!ws) return;

    ["onopen", "onmessage", "onerror", "onclose"].forEach(function(event) {
        try {
            ws[event] = null;
        } catch (e) {}
    });

    try {
        if (ws.readyState !== WebSocket.CLOSED && ws.readyState !== WebSocket.CLOSING) {
            ws.close();
        }
    } catch (e) {}

    coreLogBuffer = [];
    wsHasData = false;
}

function coreLogWebSocketRetry() {
    wsRetryTimer = setTimeout(function() {
        coreLogWebSocket();
    }, wsRetryDelay);
}

function coreLogWebSocket() {
    coreLogWebSocketStop();

    getWebSocketConnectionInfo(function(status) {
        if (!status || !status.daip || !status.cn_port || !status.clash) {
            return;
        }

        var token = status.dase;
        var level = currentLogLevel;
        var wsUrl = ocGetDashboardWebSocketOrigin(status) + "/logs?token=" + encodeURIComponent(token || "") + "&level=" + encodeURIComponent(level);

        try {
            coreWebSocket = new WebSocket(wsUrl);
            coreWebSocket.onopen = function() {
                coreLogBuffer = [];
                wsHasData = false;
            };

            coreWebSocket.onmessage = function(event) {
                if (event.data) {
                    try {
                        var msgData = JSON.parse(event.data);
                        if (msgData && msgData.payload) {
                            wsHasData = true;
                            var now = new Date();
                            var timestamp = now.getFullYear() + "-" + ocPad2(now.getMonth() + 1) + "-" + ocPad2(now.getDate()) + " " +
                                           ocPad2(now.getHours()) + ":" + ocPad2(now.getMinutes()) + ":" + ocPad2(now.getSeconds());
                            var type = msgData.type || 'info';
                            var translatedType = ocLogLevelText(type);
                            coreLogBuffer.push(timestamp + " [" + translatedType + "] " + msgData.payload);
                        }
                    } catch (e) {
                        coreLogWebSocketRetry();
                    }
                }
            };

            coreWebSocket.onerror = function(error) {
                coreLogWebSocketRetry();
            };

            coreWebSocket.onclose = function(event) {
                coreWebSocket = null;
                if (!event.wasClean) {
                    coreLogWebSocketRetry();
                }
            };
        } catch (e) {
            coreLogWebSocketRetry();
        }
    });
}

function gen_debug_logs()
{
    var btn = document.getElementById('gen_debug_button');
    var btnText = btn ? btn.querySelector('span') : null;
    var btnSvg = btn ? btn.querySelector('svg') : null;
    var originalText = btnText ? btnText.textContent : '';
    var originalSvg = btnSvg ? btnSvg.outerHTML : '';
    if (btn) {
        if (btnText) { btnText.textContent = '<%:Generating...%>'; }
        btn.disabled = true;
        if (btnSvg) {
            btnSvg.replaceWith(ocSpinner('oc-btn-spinner'));
        }
    }

    function restoreGenerateBtn() {
        if (!btn) return;
        if (btnText) { btnText.textContent = originalText; }
        btn.disabled = false;
        var sp = btn.querySelector('.loading-spinner');
        if (sp) { sp.outerHTML = originalSvg; }
    }

    restoreDebugEditor();

    var titles = document.getElementsByName('tab-header');
    if (titles.length > 2 && titles[2].className !== 'oc-tab') {
        titles[2].click();
    }

    ensureDebugEditor();

    var xhr = new XMLHttpRequest();
    xhr.timeout = 0;
    xhr.open('GET', '<%=url("admin", "services", "openclash", "gen_debug_logs")%>', true);
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');

    var lastLen = 0;
    xhr.onprogress = function() {
        var text = xhr.responseText;
        if (text.length <= lastLen) return;
        lastLen = text.length;
        var lines = text.split('\n');
        lines.pop();
        if (lines.length > 0 && lines[0].length === 8192 && /^ +$/.test(lines[0])) {
            lines.shift();
        }
        var preview = lines.join('\n');
        if (editor_debug && editor_debug.setValue) {
            editor_debug.setValue(preview);
            if (editor_debug.scrollDOM) editor_debug.scrollDOM.scrollTop = editor_debug.scrollDOM.scrollHeight;
        } else {
            dl.value = preview;
        }
    };

    xhr.onload = function() {
        restoreGenerateBtn();
        var finalText = xhr.responseText || '';

        if (xhr.status != 200 && finalText == "") {
            if (editor_debug && editor_debug.setValue) {
                editor_debug.setValue('<%:Some error occurred!%>');
            } else {
                dl.value = '<%:Some error occurred!%>';
            }
            return;
        }

        // reload after sed, because log changed
        load_debug_log();
    };

    xhr.ontimeout = function() {
        restoreGenerateBtn();
        if (xhr.responseText == "") {
            if (editor_debug && editor_debug.setValue) {
                editor_debug.setValue('<%:Request Timeout...%>');
            } else {
                dl.value = '<%:Request Timeout...%>';
            }
        }
    };

    xhr.onerror = function() {
        restoreGenerateBtn();
        if (xhr.responseText == "") {
            if (editor_debug && editor_debug.setValue) {
                editor_debug.setValue('<%:Some error occurred!%>');
            } else {
                dl.value = '<%:Some error occurred!%>';
            }
        }
    };

    xhr.send();
    return;
};

function ensureDebugEditor() {
    if (typeof markdown_editor !== 'function' || !dl) return;
    if (dl.parentNode.ocQueueStarted) return;
    markdown_editor(dl, 'debug', true, '100%', '540px');
}

function load_debug_log()
{
    XHR.get('<%=url("admin", "services", "openclash", "get_debug_logs")%>', null, function(x, status) {
        if (x && x.status == 200 && x.responseText != "")
        {
            dl.value = x.responseText;
            if (typeof editor_debug !== 'undefined' && editor_debug && editor_debug.setValue) {
                editor_debug.setValue(x.responseText);
                setCursorToFirstLineEnd(editor_debug);
            }
            if (x.responseText.replace(/\r/g, '') !== debugRenderedSrc) renderDebugView();
        }
        else
        {
            ensureDebugEditor();
        }
    });
};

function line_tolocal(input) {
    var trans_local = new Array();
    var local_count = 0;
    var lines;

    if (Array.isArray(input)) {
        lines = input;
    } else {
        lines = input.trim().split('\n');
    }

    for (var i = 0; i < lines.length; i++) {
        var v = lines[i];
        if (!v) continue;

        try {
            if (v.indexOf('time=') >= 0) {
                var regex = /(time=)"([^"]*)"/g;
                var res = regex.exec(v);

                if (res) {
                    var dt = new Date(res[2]);

                    if (!isNaN(dt.getTime())) {
                        var timestamp = dt.getFullYear() + "-" + ocPad2(dt.getMonth() + 1) + "-" + ocPad2(dt.getDate()) + " " +
                                       ocPad2(dt.getHours()) + ":" + ocPad2(dt.getMinutes()) + ":" + ocPad2(dt.getSeconds());
                        var levelMatch = v.match(/level=(\w+)/);
                        var level = levelMatch ? levelMatch[1] : 'info';
                        var translatedLevel = ocLogLevelText(level);
                        var msgMatch = v.match(/msg="(.*)"/);
                        var msg = msgMatch ? msgMatch[1] : '';
                        trans_local[local_count] = timestamp + " [" + translatedLevel + "] " + msg;
                        local_count++;
                        continue;
                    }
                }
            }
        } catch (e) {}

        trans_local[local_count] = v;
        local_count++;
    }

    return trans_local;
};

function setCursorToFirstLineEnd(editor) {
    if (!editor || !editor.state) return;
    var doc = editor.state.doc;
    if (doc.lines >= 1) {
        var fl = doc.line(1);
        editor.dispatch({ selection: { anchor: fl.to }, scrollIntoView: true });
    }
}

function trimEditorLog(view) {
    var doc = view.state.doc;
    if (doc.lines <= logMaxLines) return false;
    view.dispatch({ changes: { from: doc.line(logMaxLines - 1).to, to: doc.length, insert: '\n...' } });
    return true;
}

function smoothlyDisplayLogs(newLines, target, isEditor, currentContent, isActiveTab) {
    var scrollPosition = null;
    var isAtTop = false;
    var cursorPos = null;
    var selectionRange = null;

    if (isEditor && target) {
        scrollPosition = target.getScrollInfo();
        isAtTop = (scrollPosition.top < 20);

        if (target.hasFocus()) {
            cursorPos = target.getCursor();

            if (cursorPos.line === 0) {
                cursorPos = null;
                selectionRange = null;
            } else if (target.somethingSelected()) {
                selectionRange = {
                    from: target.getCursor(true),
                    to: target.getCursor(false)
                };
            } else {
                selectionRange = null;
            }
        } else {
            cursorPos = null;
            selectionRange = null;
        }
    } else if (!isEditor && target) {
        scrollPosition = target.scrollTop;
        isAtTop = (target.scrollTop < 20);
    }

    if ((target === editor_oc && animatingOC) || (target === editor_core && animatingCore) || (target === editor_debug && animatingDebug) || !isActiveTab) {
        var lines = newLines.slice().reverse();
        var content = lines.join('\n') + (lines.length > 0 ? '\n' : '') + (currentContent || '');

        if (isEditor) {
            var addedLines = lines.length;
            target.setValue(content);
            trimEditorLog(target);

            if (!isAtTop && scrollPosition) {
                if (cursorPos) {
                    cursorPos.line += addedLines;
                    target.setCursor(cursorPos);
                    target.scrollIntoView({line: cursorPos.line, ch: cursorPos.ch}, 300);
                } else {
                    target.scrollTo(scrollPosition.left, scrollPosition.top);
                }

                if (selectionRange) {
                    selectionRange.from.line += addedLines;
                    selectionRange.to.line += addedLines;
                    target.setSelection(selectionRange.from, selectionRange.to);
                    target.scrollIntoView({
                        from: selectionRange.from,
                        to: selectionRange.to
                    }, 300);
                }
            } else if (isAtTop) {
                target.scrollTo(0, 0);
                if (!cursorPos) {
                    var firstLineLen = target.state.doc.line(1).length;
                    target.setCursor({line: 0, ch: firstLineLen});
                }
            }
        } else {
            var allLines = content.split("\n");
            if (allLines.length > logMaxLines) {
                allLines = allLines.slice(0, logMaxLines - 1);
                allLines.push("...");
                content = allLines.join("\n");
            }
            var oldScrollTop = scrollPosition;
            target.innerHTML = content;
            if (!isAtTop && oldScrollTop) {
                target.scrollTop = oldScrollTop;
            }
        }
        return;
    }

    if (target === editor_oc || target === lv) {
        animatingOC = true;
    } else if (target === editor_debug) {
        animatingDebug = true;
    } else {
        animatingCore = true;
    }

    var totalLines = newLines.length;
    var batchSize, interval;

    if (totalLines <= 10) {
        batchSize = 5;
        interval = 80;
    } else if (totalLines <= 50) {
        batchSize = 25;
        interval = 50;
    } else if (totalLines <= 200) {
        batchSize = 60;
        interval = 30;
    } else if (totalLines <= 500) {
        batchSize = 150;
        interval = 20;
    } else if (totalLines <= 1000) {
        batchSize = 300;
        interval = 12;
    } else if (totalLines <= 1500) {
        batchSize = 400;
        interval = 8;
    } else {
        batchSize = 500;
        interval = 5;
    }

    var displayedContent = currentContent || "";
    var logLines = newLines.slice();
    var currentBatchCount = 0;
    var accumulatedContent = "";

    function displayNextBatch() {
        if (currentBatchCount >= logLines.length) {
            if (target === editor_oc || target === lv) {
                animatingOC = false;
            } else if (target === editor_debug) {
                animatingDebug = false;
            } else {
                animatingCore = false;
            }

            if (isEditor && !isAtTop && cursorPos) {
                cursorPos.line += logLines.length;
                target.setCursor(cursorPos);

                if (selectionRange) {
                    selectionRange.from.line += logLines.length;
                    selectionRange.to.line += logLines.length;
                    target.setSelection(selectionRange.from, selectionRange.to);

                    target.scrollIntoView({
                        from: selectionRange.from,
                        to: selectionRange.to
                    }, 300);
                } else {
                    target.scrollIntoView({line: cursorPos.line, ch: cursorPos.ch}, 300);
                }
            }
            if (isEditor && !cursorPos) {
                setCursorToFirstLineEnd(target);
            }
            return;
        }

        var nextBatchSize = Math.min(batchSize, logLines.length - currentBatchCount);

        var batchLines = logLines.slice(currentBatchCount, currentBatchCount + nextBatchSize).reverse();
        currentBatchCount += nextBatchSize;

        if (accumulatedContent) {
            accumulatedContent = batchLines.join("\n") + "\n" + accumulatedContent;
        } else {
            accumulatedContent = batchLines.join("\n");
        }

        var content = accumulatedContent + (displayedContent ? "\n" + displayedContent : "");

        if (isEditor) {
            var currentScrollInfo = isAtTop ? null : target.getScrollInfo();
            target.setValue(content);

            if (!isAtTop && currentScrollInfo) {
                target.scrollTo(currentScrollInfo.left, currentScrollInfo.top);
            }
        } else {
            var currentScrollTop = isAtTop ? null : target.scrollTop;
            target.innerHTML = content;
            if (!isAtTop && currentScrollTop !== null) {
                target.scrollTop = currentScrollTop;
            }
        }

        if (currentBatchCount < logLines.length) {
            setTimeout(displayNextBatch, interval);
        } else {
            if (target === editor_oc || target === lv) {
                animatingOC = false;
            } else if (target === editor_debug) {
                animatingDebug = false;
            } else {
                animatingCore = false;
            }

            if (isEditor && !isAtTop && cursorPos) {
                cursorPos.line += logLines.length;
                target.setCursor(cursorPos);

                if (selectionRange) {
                    selectionRange.from.line += logLines.length;
                    selectionRange.to.line += logLines.length;
                    target.setSelection(selectionRange.from, selectionRange.to);

                    target.scrollIntoView({
                        from: selectionRange.from,
                        to: selectionRange.to
                    }, 300);
                } else {
                    target.scrollIntoView({line: cursorPos.line, ch: cursorPos.ch}, 300);
                }
            }
            if (isEditor && !cursorPos) {
                setCursorToFirstLineEnd(target);
            }

            if (isEditor && trimEditorLog(target) && !cursorPos) {
                setCursorToFirstLineEnd(target);
            }
        }
    }

    displayNextBatch();
}

function poll_log(){
    var activeTabId = 0;
    var titles = document.getElementsByName('tab-header');
    var core_logs = [];
    var oc_logs = [];
    var currentCoreContent = "";
    var currentContent = "";
    var bufferToProcess = [];

    clearTimeout(r);

    for(var i=0; i<titles.length; i++){
        if(titles[i].className === 'oc-tab') {
            activeTabId = i;
            break;
        }
    }

    if (coreWebSocket && coreWebSocket.readyState == WebSocket.OPEN) {
        core_refresh = !wsHasData;
        if (coreLogBuffer.length > 0) {
            bufferToProcess = coreLogBuffer;
            coreLogBuffer = [];
            core_logs = line_tolocal(bufferToProcess);
            if (editor_core && activeTabId === 1) {
                currentCoreContent = editor_core.getValue();
                smoothlyDisplayLogs(core_logs, editor_core, true, currentCoreContent, true);
            } else {
                accumulateCoreLog(core_logs);
            }
        }
    } else {
        core_refresh = true;
    }

    if (isPolling) {
        r = setTimeout("poll_log()", pollInterval);
        return;
    }

    if (activeTabId === 2) {
        return;
    }

    isPolling = true;

    XHR.get('<%=url("admin", "services", "openclash", "refresh_log")%>',
        {
            log_len: log_len, core_refresh: core_refresh
        },
        function(x, status) {
            if (x && x.status == 200) {
                if (status) {
                    if (!status.update) {
                        isPolling = false;
                        r = setTimeout("poll_log()", pollInterval);
                        return;
                    }

                    if (status.len) {
                        log_len = status.len;
                    }

                    if (status.oc_log && status.oc_log !== "") {
                        oc_logs = line_tolocal(status.oc_log);

                        if (oc_logs.length > 0) {
                            if (editor_oc) {
                                currentContent = editor_oc.getValue();
                                smoothlyDisplayLogs(oc_logs, editor_oc, true, currentContent, activeTabId === 0);
                            } else if (lv) {
                                currentContent = lv.innerHTML;
                                smoothlyDisplayLogs(oc_logs, lv, false, currentContent, activeTabId === 0);
                            }
                        }
                    }

                    if (status.core_log && status.core_log !== "") {
                        core_logs = line_tolocal(status.core_log);

                        if (core_logs.length > 0) {
                            if (editor_core && activeTabId === 1) {
                                currentCoreContent = editor_core.getValue();
                                smoothlyDisplayLogs(core_logs, editor_core, true, currentCoreContent, true);
                            } else {
                                accumulateCoreLog(core_logs);
                            }
                        }
                    }
                }
            }
            isPolling = false;
            r = setTimeout("poll_log()", pollInterval);
        }
    );
};

function syncTabHeight() {
    var tc = document.getElementById('tab-content');
    if (!tc || activeTabPane < 0 || !tabPanes[activeTabPane]) return;
    tc.style.height = tabPanes[activeTabPane].offsetHeight + 'px';
}

// Panes stay alive and laid out; switching only moves the inactive ones
// off-screen with a composited transform (no style/layout invalidation).
function activateTabPane(id) {
    activeTabPane = +id;
    for (var i = 0; i < tabPanes.length; i++) {
        tabPanes[i].style.transform = (i === activeTabPane) ? 'none' : 'translateX(-200%)';
        tabPanes[i].style.zIndex = (i === activeTabPane) ? '1' : '';
    }
    syncTabHeight();
}

window.onload = function(){
    var titles = document.getElementsByName('tab-header');
    var divs = document.getElementsByClassName('dom');
    if(titles.length != divs.length) return;

    var tc = document.getElementById('tab-content');
    if (tc) tc.style.position = 'relative';

    activateTabPane(0);
    if (window.ResizeObserver) {
        var paneResizer = new ResizeObserver(function() { syncTabHeight(); });
        for (var p = 0; p < tabPanes.length; p++) paneResizer.observe(tabPanes[p]);
    }

    for(var i=0; i<titles.length; i++){
        var li = titles[i];
        li.id = i;
        function handleTabSwitch(tab) {
            return function(e) {
                if (tab.className === 'oc-tab') return;
                var prevTabId = -1;
                for(var j=0; j<titles.length; j++){
                    if (titles[j].className === 'oc-tab') prevTabId = j;
                    titles[j].className = 'oc-tab-disabled';
                    titles[j].setAttribute('aria-selected', 'false');
                }
                tab.className = 'oc-tab';
                tab.setAttribute('aria-selected', 'true');
                activateTabPane(tab.id);

                if (prevTabId == 1 && editor_core) {
                    coreLogAccumulator = editor_core.getValue();
                    coreLogLines = coreLogAccumulator === '' ? [] : coreLogAccumulator.split('\n');
                    cl.value = coreLogAccumulator;
                }

                if (tab.id == 0 && typeof editor_oc !== 'undefined' && editor_oc) {
                    setCursorToFirstLineEnd(editor_oc);
                }

                if (tab.id == 1 && !coreEditorInitialized) {
                    coreEditorInitialized = true;
                    if (typeof log_editor === 'function' && cl) {
                        cl.value = coreLogAccumulator.replace(/\n+$/, '');
                        log_editor(cl, 'core', true, '100%', '540px');
                    }
                } else if (tab.id == 1 && editor_core) {
                    editor_core.setValue(coreLogAccumulator.replace(/\n+$/, ''));
                    editor_core.refresh();
                    setCursorToFirstLineEnd(editor_core);
                }

                if (tab.id == 2) {
                    if (typeof editor_debug !== 'undefined' && editor_debug) {
                        setCursorToFirstLineEnd(editor_debug);
                    } else if (!debugRenderedSrc) {
                        load_debug_log();
                    }
                }

                pollInterval = (tab.id == 1) ? 5000 : 1000;
                clearTimeout(r);
                poll_log();
            };
        }

        li.onclick = handleTabSwitch(li);
        li.ontouchstart = handleTabSwitch(li);
    }
    get_log_level();
    poll_log();
    // Preload the debug log in the background (upstream behavior) so opening
    // the debug tab never starts the fetch and render at click time.
    ocRequireCM6(function() {
        setTimeout(load_debug_log, 500);
    });
};

function debugParts(text) {
    var parts = [];
    var lines = text.split('\n');
    var buf = [];
    var size = 0;
    var fenced = false;
    var target = 24000;
    for (var i = 0; i < lines.length; i++) {
        if (lines[i].replace(/^\s+/, '').indexOf('```') === 0) fenced = !fenced;
        buf.push(lines[i]);
        size += lines[i].length + 1;
        if (!fenced && size >= target) {
            parts.push(buf.join('\n'));
            buf = [];
            size = 0;
        }
    }
    if (buf.length) parts.push(buf.join('\n'));
    return parts;
}

function decorateDebugBlocks(host) {
    var pres = host.querySelectorAll('pre');
    var copyIcon = '<svg width="14" height="14"><use href="#oc-icon-copy"/></svg>';
    for (var i = 0; i < pres.length; i++) {
        (function(pre) {
            if (pre.parentNode && pre.parentNode.classList.contains('pre-copy-wrap')) return;
            var btn = document.createElement('div');
            btn.className = 'pre-copy-btn';
            btn.title = '<%:Copy%>';
            btn.innerHTML = copyIcon;
            btn.onclick = function(e) {
                e.stopPropagation();
                var text = pre.textContent || '';
                ocCopyToClipboard(text, btn);
            };
            var wrap = document.createElement('div');
            wrap.className = 'pre-copy-wrap';
            pre.parentNode.insertBefore(wrap, pre);
            wrap.appendChild(pre);
            wrap.appendChild(btn);
        })(pres[i]);
    }
}

// Render the debug log in fence-balanced chunks, one per frame: a single
// pass over a large log blocks the page for seconds.
function renderDebugChunks(host, text) {
    var token = ++debugRenderToken;
    if (typeof CM6 === 'undefined' || !CM6.renderMarkdown) {
        host.innerHTML = text.replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\n/g,'<br>');
        return;
    }
    debugRenderedSrc = text.replace(/\r/g, '');
    var parts = debugParts(text);
    var index = 0;
    host.innerHTML = '';
    function schedule(fn) {
        if (document.visibilityState === 'visible' && window.requestAnimationFrame) requestAnimationFrame(fn);
        else setTimeout(fn, 16);
    }
    function step() {
        if (token !== debugRenderToken) return;
        host.insertAdjacentHTML('beforeend', CM6.renderMarkdown(parts[index]));
        index++;
        if (index >= parts.length) { decorateDebugBlocks(host); return; }
        schedule(step);
    }
    step();
}

function renderDebugView(src) {
    var wrapper = document.getElementById('debug-render-wrapper');
    var rendered = document.getElementById('debug-rendered');
    if (!wrapper || !rendered) return;
    if (!src) {
        if (typeof editor_debug !== 'undefined' && editor_debug) {
            src = editor_debug.getValue();
        } else if (dl) {
            src = dl.value || '';
        }
    }
    if (!src) return;

    function paintDebugView() {
        if (typeof editor_debug !== 'undefined' && editor_debug && editor_debug.dom) {
            editor_debug.dom.style.setProperty('display', 'none', 'important');
        }
        var cms = dl.parentNode.querySelectorAll('.cm-editor');
        for (var i = 0; i < cms.length; i++) {
            cms[i].style.setProperty('display', 'none', 'important');
        }

        wrapper.style.display = 'block';
        dl.style.display = 'none';
        if (dl.parentNode && dl.parentNode.className.indexOf('oc') < 0) {
            dl.parentNode.classList.add('oc');
        }

        renderDebugChunks(rendered, src);
    }

    if (typeof CM6 !== 'undefined' && CM6.ensureMarkdown) {
        CM6.ensureMarkdown(paintDebugView);
    } else {
        paintDebugView();
    }
}

function copyDebugSource() {
    var src = '';
    if (typeof editor_debug !== 'undefined' && editor_debug) {
        src = editor_debug.getValue();
    } else if (dl) {
        src = dl.value || '';
    }
    if (!src) return;
    ocCopyToClipboard(src, document.getElementById('debug-copy-source'));
}
