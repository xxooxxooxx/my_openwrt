// Extracted from luasrc/view/openclash/config_merge_editor.htm - edit this file, not the template.
// <%:Message%> markers and <%=...%> islands are compiled server-side by the "openclash/translate_js" controller action.

var ocIcons = {
    SVG_COMPARE: '<svg width="18" height="18"><use href="#oc-icon-compare"/></svg>',
    SVG_RESTORE: '<svg width="18" height="18"><use href="#oc-icon-restore"/></svg>'
};

// Uses EditorView.updateListener instead of view.dispatch override.
// dispatch() can receive TransactionSpec objects which lack docChanged.

function config_merge_editor(id, id2, target, target2, readOnly, readOnly2, wid, height) {
    id.style.display = "none";
    id2.style.display = "none";

    var descr = document.getElementById("my_editor_div");
    var cbiMap = target.closest('.cbi-map');
    var sectionTable = cbiMap ? cbiMap.querySelector('.cbi-section') : null;
    if (!cbiMap || !sectionTable) return;

    cbiMap.classList.add('oc');
    var wrapper = document.createElement('div');
    wrapper.classList.add('cbi-section-card');
    while (cbiMap.firstChild) {
        wrapper.appendChild(cbiMap.firstChild);
    }
    cbiMap.appendChild(wrapper);

    descr.style.display = "flex";
    wrapper.insertBefore(descr, sectionTable);

    var editorCell = target.parentNode;
    editorCell.classList.add('oc-merge-cell');

    var toggleBtn = document.getElementById('oc-merge-toggle-btn');
    if (toggleBtn) {
        editorCell.appendChild(toggleBtn);
        toggleBtn.style.display = 'flex';
        toggleBtn.onclick = function(e) {
            e.preventDefault();
            e.stopPropagation();
            toggleMergeView();
        };
    }

    var helpEl = document.getElementById('oc-merge-help');
    if (helpEl) {
        helpEl.classList.remove('oc-hidden');
        var helpNormal = document.getElementById('oc-merge-help-normal');
        var helpMerge = document.getElementById('oc-merge-help-merge');
        if (helpNormal) helpNormal.innerHTML = ocEditorHelpHtml(false);
        if (helpMerge) helpMerge.innerHTML = ocEditorHelpHtml(true);
        var footer = document.createElement('div');
        footer.className = 'config-editor-footer oc-merge-footer';
        var statusDiv = document.createElement('div');
        statusDiv.className = 'config-editor-status';
        var mergeModeLabel = document.createElement('span');
        mergeModeLabel.id = 'oc-merge-mode-label';
        mergeModeLabel.style.display = 'none';
        mergeModeLabel.textContent = '<%:Compare mode: left(Original Config), right(Runtime Config)%>';
        statusDiv.appendChild(mergeModeLabel);
        var helpDiv = document.createElement('div');
        helpDiv.className = 'config-editor-help';
        helpDiv.appendChild(helpEl);
        footer.appendChild(statusDiv);
        footer.appendChild(helpDiv);
        wrapper.insertBefore(footer, sectionTable.nextSibling);
        updateMergeHelpText(false);
    }

    var sectionDescr = wrapper.querySelector('.cbi-section-descr');
    if (sectionDescr) {
        sectionDescr.classList.add('config-editor-header', 'config-editor-title', 'oc-merge-section-descr');
        var text = sectionDescr.textContent.trim();
        var idx = text.indexOf(':');
        if (idx > 0) {
            var label = text.substring(0, idx + 1);
            var fname = text.substring(idx + 1).trim();
            sectionDescr.innerHTML = '<span id="editTitle">' + label + '</span> ' +
                '<span id="config-file-name" class="config-file-name">' + fname + '</span>';
        }
        wrapper.insertBefore(sectionDescr, descr);
    }

    target2.parentNode.style.display = "none";
    target.parentNode.colSpan = 2;
    target.classList.add('oc-merge-area');

    var useContent = id.value || '';
    var defContent = id2.value || '';
    var showUse = useContent !== '';

    window.mergeEditorState = {
        id: id,
        id2: id2,
        target: target,
        target2: target2,
        wid: wid,
        height: height,
        isMerge: false,
        showUse: showUse,
        useContent: useContent,
        defContent: defContent,
        instance: null,
        readOnlyCompartment: null,
        programmaticChange: false
    };

    createSingleMergeEditor(showUse ? useContent : defContent, !showUse);

    updateMergeToggleBtn();
    updateMergeTabs(false);

    var tabOriginal = document.getElementById('tab-original-config');
    var tabRuntime = document.getElementById('tab-runtime-config');

    if (tabOriginal) {
        tabOriginal.onclick = function(e) {
            e.preventDefault();
            var state = window.mergeEditorState;
            if (!state) return;
            if (state.instance) {
                if (state.isMerge && state.instance.a && state.instance.a.state) {
                    state.useContent = state.instance.a.state.doc.toString();
                } else if (!state.isMerge && state.instance.state) {
                    var cur = state.instance.state.doc.toString();
                    if (state.showUse) state.useContent = cur;
                }
            }
            if (state.isMerge) {
                state.showUse = true;
                createSingleMergeEditor(state.useContent, false);
                document.getElementById('my_editor_div').classList.remove('oc-hidden');
            } else if (!state.showUse) {
                state.showUse = true;
                switchSingleTab(state.useContent, false);
            }
            updateMergeToggleBtn();
            updateMergeTabs(false);
        };
    }

    if (tabRuntime) {
        tabRuntime.onclick = function(e) {
            e.preventDefault();
            var state = window.mergeEditorState;
            if (!state) return;
            if (state.instance) {
                if (state.isMerge && state.instance.a && state.instance.a.state) {
                    state.useContent = state.instance.a.state.doc.toString();
                } else if (!state.isMerge && state.instance.state) {
                    var cur = state.instance.state.doc.toString();
                    if (state.showUse) state.useContent = cur;
                }
            }
            if (state.isMerge) {
                state.showUse = false;
                createSingleMergeEditor(state.defContent, true);
                document.getElementById('my_editor_div').classList.remove('oc-hidden');
            } else if (state.showUse) {
                state.showUse = false;
                switchSingleTab(state.defContent, true);
            }
            updateMergeToggleBtn();
            updateMergeTabs(false);
        };
    }
}

function switchSingleTab(content, readOnly) {
    var state = window.mergeEditorState;
    if (!state || !state.instance || state.isMerge) return;

    var view = state.instance;
    state.programmaticChange = true;
    view.dispatch({
        changes: { from: 0, to: view.state.doc.length, insert: content }
    });
    if (state.readOnlyCompartment) {
        view.dispatch({
            effects: state.readOnlyCompartment.reconfigure(
                readOnly ? CM6.EditorState.readOnly.of(true) : []
            )
        });
    }
    state.programmaticChange = false;
}

function createSingleMergeEditor(content, readOnly) {
    var state = window.mergeEditorState;
    if (!state) return;
    destroyMergeInstance();

    if (state.target) {
        var orphans = state.target.querySelectorAll('.cm-editor, .cm-mergeView');
        for (var i = 0; i < orphans.length; i++) { orphans[i].remove(); }
        state.target.classList.add('oc-merge-area');
        if (state.target.parentNode) state.target.parentNode.colSpan = 2;
    }

    ocShowLoading(state.target, '<%:Loading...%>');

    var isDark = isDarkBackground(document.body);
    var exts = [CM6.baseExtensions(), CM6.themeExtension(isDark), CM6.placeholderExtension('<%:Enter YAML configuration...%>')];
    var topSearch = (CM6 && CM6.topSearchExtension) ? CM6.topSearchExtension() : null;
    if (topSearch) exts.push(topSearch);
    exts.push(CM6.yaml());
    exts.push(CM6.yamlLinter());
    exts.push(CM6.lintGutter());
    exts.push(CM6.autocompletion({ override: [CM6.mihomoCompletion] }));
    exts.push(CM6.indentUnit.of("  "));
    exts.push(CM6.indentMarkerExtension());
    var readOnlyComp = new CM6.Compartment();
    exts.push(readOnlyComp.of(readOnly ? CM6.EditorState.readOnly.of(true) : []));
    state.readOnlyCompartment = readOnlyComp;

    exts.push(CM6.EditorView.updateListener.of(function(update) {
        if (update.docChanged && !state.programmaticChange) {
            state.id.value = update.state.doc.toString();
            state.useContent = update.state.doc.toString();
        }
    }));

    var mergeStatus = document.querySelector('.config-editor-status');
    if (mergeStatus) mergeStatus.classList.add('oc-hidden');

    var view = new CM6.EditorView({
        state: CM6.EditorState.create({ doc: content, extensions: exts }),
        parent: state.target
    });
    var btn = document.getElementById('oc-merge-toggle-btn');
    if (btn && view.dom) view.dom.appendChild(btn);
    if (state.wid && state.height) {
        view.dom.style.width = state.wid;
        view.dom.style.height = state.height;
    }
    state.instance = view;
    state.isMerge = false;

    if (CM6.mirrorThemeScrollbar) CM6.mirrorThemeScrollbar();

    ocHideLoading(state.target);
}

function renderMergeView() {
    var state = window.mergeEditorState;
    if (!state) return;
    destroyMergeInstance();

    if (state.target) {
        var orphans = state.target.querySelectorAll('.cm-editor');
        for (var i = 0; i < orphans.length; i++) { orphans[i].remove(); }
        state.target.classList.add('oc-merge-area');
        if (state.target.parentNode) state.target.parentNode.colSpan = 2;
    }

    ocShowLoading(state.target, '<%:Loading...%>');

    var isDark = isDarkBackground(document.body);
    var topSearch = (CM6 && CM6.topSearchExtension) ? CM6.topSearchExtension() : null;
      var extA = [CM6.baseExtensions([], { preload: false }), CM6.themeExtension(isDark), CM6.placeholderExtension('<%:Edit original config...%>'), CM6.yaml(), CM6.yamlLinter(), CM6.lintGutter(), CM6.autocompletion({ override: [CM6.mihomoCompletion] }), CM6.indentUnit.of("  "), CM6.indentMarkerExtension(), CM6.parseAheadExtension()];
      var extB = [CM6.baseExtensions([], { preload: false }), CM6.themeExtension(isDark), CM6.placeholderExtension('<%:Runtime config (read only)%>'), CM6.yaml(), CM6.indentUnit.of("  "), CM6.indentMarkerExtension(), CM6.EditorState.readOnly.of(true), CM6.parseAheadExtension()];
    var mergeDefaults = CM6.mergeDefaultConfig || {};
    if (topSearch) {
        extA.push(topSearch);
        extB.push(topSearch);
    }

    extA.push(CM6.EditorView.updateListener.of(function(update) {
        if (update.docChanged) {
            state.id.value = update.state.doc.toString();
            state.useContent = update.state.doc.toString();
        }
    }));

    var mv = new CM6.MergeView({
        a: { doc: state.useContent || '', extensions: extA },
        b: { doc: state.defContent || '', extensions: extB },
        parent: state.target,
        diffConfig: mergeDefaults.diffConfig || { scanLimit: 5000 },
        gutter: mergeDefaults.gutter !== false,
        revertControls: mergeDefaults.revertControls || 'b-to-a',
        highlightChanges: window.ocMergeShowDifferences,
        collapseUnchanged: mergeDefaults.collapseUnchanged || false
    });

    if (state.wid && state.height) {
        mv.a.dom.style.width = state.wid;
        mv.a.dom.style.height = state.height;
        mv.b.dom.style.width = state.wid;
        mv.b.dom.style.height = state.height;
    }

    if (CM6.mirrorThemeScrollbar) CM6.mirrorThemeScrollbar();

    var btn = document.getElementById('oc-merge-toggle-btn');
    if (btn && mv.dom) mv.dom.appendChild(btn);

    var mergeStatus = document.querySelector('.config-editor-status');
    if (mergeStatus) mergeStatus.classList.remove('oc-hidden');
    var mergeLabel = document.getElementById('oc-merge-mode-label');
    if (mergeLabel) mergeLabel.classList.remove('oc-hidden');

    window.mergeViewInstance = mv;
    window.ocMergeShowDifferences = true;
    state.instance = mv;
    state.isMerge = true;

    ocHideLoading(state.target);
}

function destroyMergeInstance() {
    var btn = document.getElementById('oc-merge-toggle-btn');
    if (btn) {
        var editorCell = window.mergeEditorState && window.mergeEditorState.target ? window.mergeEditorState.target.parentNode : null;
        if (editorCell) editorCell.appendChild(btn);
    }
    var state = window.mergeEditorState;
    if (state && state.instance) {
        try {
            if (state.instance.a && state.instance.a.destroy) {
                state.instance.a.destroy();
                if (state.instance.b && state.instance.b.destroy) state.instance.b.destroy();
            } else if (state.instance.destroy) {
                state.instance.destroy();
            }
        } catch(e) {}
        state.instance = null;
    }
    window.mergeViewInstance = null;
}

function updateMergeHelpText(isMerge) {
    var helpNormal = document.getElementById('oc-merge-help-normal');
    var helpMerge = document.getElementById('oc-merge-help-merge');
    if (helpNormal) {
        if (isMerge) helpNormal.classList.add('oc-hidden');
        else helpNormal.classList.remove('oc-hidden');
    }
    if (helpMerge) {
        if (isMerge) helpMerge.classList.remove('oc-hidden');
        else helpMerge.classList.add('oc-hidden');
    }
}

function toggleMergeView() {
    var state = window.mergeEditorState;
    if (!state) return;

    if (state.instance) {
        if (state.isMerge && state.instance.a && state.instance.a.state) {
            state.useContent = state.instance.a.state.doc.toString();
        } else if (!state.isMerge && state.instance.state) {
            var cur = state.instance.state.doc.toString();
            if (state.showUse) state.useContent = cur;
        }
    }

    var wasFullscreen = window.ocFullscreenActive;

    if (state.isMerge) {
        state.showUse = true;
        createSingleMergeEditor(state.useContent, false);
        document.getElementById('my_editor_div').classList.remove('oc-hidden');
    } else {
        renderMergeView();
        document.getElementById('my_editor_div').classList.add('oc-hidden');
    }
    updateMergeToggleBtn();
    updateMergeTabs(state.isMerge);
    updateMergeHelpText(state.isMerge);

    if (wasFullscreen && CM6 && CM6.toggleFullscreen) {
        var target = state.instance && state.instance.dom ? state.instance.dom : null;
        if (!target && CM6.getActiveEditor) target = CM6.getActiveEditor();
        if (target) CM6.toggleFullscreen(target);
    }
}

function updateMergeToggleBtn() {
    var btn = document.getElementById('oc-merge-toggle-btn');
    if (!btn) return;
    var state = window.mergeEditorState;
    if (state && state.isMerge) {
        btn.title = '<%:Restore%>';
        btn.innerHTML = ocIcons.SVG_RESTORE;
    } else {
        btn.title = '<%:Compare%>';
        btn.innerHTML = ocIcons.SVG_COMPARE;
    }
}

function updateMergeTabs(isMerge) {
    var tabOriginal = document.getElementById('tab-original-config');
    var tabRuntime = document.getElementById('tab-runtime-config');
    if (!tabOriginal || !tabRuntime) return;
    if (isMerge) {
        tabOriginal.classList.remove('active');
        tabRuntime.classList.remove('active');
    } else {
        var state = window.mergeEditorState;
        if (state && state.showUse) {
            tabOriginal.classList.add('active');
            tabRuntime.classList.remove('active');
        } else {
            tabOriginal.classList.remove('active');
            tabRuntime.classList.add('active');
        }
    }
}

ocRegisterEditorHotkeys();
