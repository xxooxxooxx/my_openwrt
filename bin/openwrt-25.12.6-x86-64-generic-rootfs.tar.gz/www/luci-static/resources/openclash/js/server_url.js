// Extracted from luasrc/view/openclash/server_url.htm - edit this file, not the template.
// <%:Message%> markers and <%=...%> islands are compiled server-side by the "openclash/translate_js" controller action.

function padright(str, cnt, pad) {
    return str + Array(cnt + 1).join(pad);
}

function b64EncodeUnicode(str) {
    return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, function (match, p1) {
        return String.fromCharCode('0x' + p1);
    }));
}

function b64encutf8safe(str) {
    return b64EncodeUnicode(str).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, '');
}

function b64DecodeUnicode(str) {
    return decodeURIComponent(Array.prototype.map.call(atob(str), function (c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
}

function b64decutf8safe(str) {
    var l;
    str = str.replace(/-/g, "+").replace(/_/g, "/");
    l = str.length;
    l = (4 - l % 4) % 4;
    if (l) str = padright(str, l, "=");
    return b64DecodeUnicode(str);
}

function b64encsafe(str) {
    return btoa(str).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, '')
}

function b64decsafe(str) {
    var l;
    str = str.replace(/-/g, "+").replace(/_/g, "/");
    l = str.length;
    l = (4 - l % 4) % 4;
    if (l) str = padright(str, l, "=");
    return atob(str);
}

function parseUrl(url) {
    var m = url.match(/^(([^:\/?#]+:)?(?:\/\/((?:(?:([^\/?#:]*)(?::([^\/?#:]*))?)@)?([^\/?#:]*)(?::([^\/?#:]*))?)))?([^?#]*)(\?[^#]*)?(#.*)?$/);
    if (!m) {
        try {
            var u = new URL(url);
            return {
                hash: u.hash || "",
                host: u.host || "",
                hostname: u.hostname || "",
                href: u.href || "",
                origin: u.origin || "",
                pathname: u.pathname || "",
                port: u.port || "",
                protocol: u.protocol || "",
                search: u.search || "",
                username: u.username || "",
                password: u.password || ""
            };
        } catch (e) {
            return null;
        }
    }
    return {
        hash: m[10] || "",
        host: m[3] || "",
        hostname: m[6] || "",
        href: m[0] || "",
        origin: m[1] || "",
        pathname: m[8] || (m[1] ? "/" : ""),
        port: m[7] || "",
        protocol: m[2] || "",
        search: m[9] || "",
        username: m[4] || "",
        password: m[5] || ""
    };
}

function decodeFragment(fragment) {
    if (!fragment) return '';
    try {
        var decoded = decodeURIComponent(fragment);
        while (decoded !== fragment) {
            fragment = decoded;
            decoded = decodeURIComponent(fragment);
        }
        return fragment;
    } catch (e) {
        return fragment;
    }
}

function parseQuery(search) {
    var query = {};
    if (search && search.length > 1) {
        var params = search.substring(1).split('&');
        for (var i = 0; i < params.length; i++) {
            var eqIndex = params[i].indexOf('=');
            if (eqIndex !== -1) {
                var key = params[i].substring(0, eqIndex);
                var value = params[i].substring(eqIndex + 1);
                try {
                    key = decodeURIComponent(key);
                    if (query.hasOwnProperty(key)) {
                        if (isYamlListLikeKey(key) || key === 'port' || key === 'protocol') {
                            query[key] = String(query[key]) + ',' + value;
                        } else {
                            query[key] = value;
                        }
                    } else {
                        query[key] = value;
                    }
                } catch (e) {
                    if (query.hasOwnProperty(key)) {
                        if (isYamlListLikeKey(key) || key === 'port' || key === 'protocol') {
                            query[key] = String(query[key]) + ',' + value;
                        } else {
                            query[key] = value;
                        }
                    } else {
                        query[key] = value;
                    }
                }
            }
        }
    }
    return query;
}

function getFormElements(sid, field) {
    var baseName = 'cbid.openclash.' + sid + '.' + field;
    var multiValueField = isMultiValueField(field);

    if (multiValueField) {
        var multiList = document.getElementsByName(baseName + '[]');
        if (multiList && multiList.length > 0) return multiList;
    }

    var list = document.getElementsByName(baseName);
    if (list && list.length > 0) return list;

    list = document.getElementsByName(baseName + '[]');
    if (list && list.length > 0) return list;

    var byId = document.getElementById(baseName);
    if (byId) return [byId];

    return [];
}

function dispatchFieldChange(element) {
    var inputEvent = document.createEvent("HTMLEvents");
    inputEvent.initEvent("input", true, true);
    element.dispatchEvent(inputEvent);

    var event = document.createEvent("HTMLEvents");
    event.initEvent("change", true, true);
    element.dispatchEvent(event);
}

function getCodeMirrorInstance(element) {
    if (!element || !element.tagName || element.tagName.toLowerCase() !== 'textarea') return null;

    if (element.nextSibling && element.nextSibling.CodeMirror) {
        return element.nextSibling.CodeMirror;
    }

    if (element.parentNode) {
        var cmNode = element.parentNode.querySelector('.CodeMirror');
        if (cmNode && cmNode.CodeMirror) {
            return cmNode.CodeMirror;
        }
    }

    return null;
}

function setElementValue(element, value) {
    var normalized = String(value == null ? '' : value);

    var type = (element.type || '').toLowerCase();
    if (type === 'checkbox') {
        var checked = /^(1|true|on|yes)$/i.test(normalized);
        element.checked = checked;
        if (!element.value) {
            element.value = '1';
        }
        dispatchFieldChange(element);
        return;
    }

    if (type === 'radio') {
        element.checked = String(element.value) === normalized;
        dispatchFieldChange(element);
        return;
    }

    element.value = normalized;

    var cm = getCodeMirrorInstance(element);
    if (cm) {
        cm.setValue(normalized);
        cm.save();
    }

    dispatchFieldChange(element);
}

function getElementValue(element) {
    var cm = getCodeMirrorInstance(element);
    if (cm) {
        return cm.getValue();
    }
    return element.value;
}

function getDynamicListContainer(sid, field) {
    var baseName = 'cbid.openclash.' + sid + '.' + field;
    return document.querySelector('div[data-prefix="' + baseName + '"]');
}

function getDynamicListInputs(sid, field) {
    var baseName = 'cbid.openclash.' + sid + '.' + field;
    var container = getDynamicListContainer(sid, field);
    if (!container) return [];
    var selector = 'input[name="' + baseName + '"], input[name="' + baseName + '[]"]';
    var nodeList = container.querySelectorAll(selector);
    return Array.prototype.slice.call(nodeList || []);
}

function syncDynamicListSelect(inputElement, value) {
    if (!inputElement || !inputElement.id) return;

    var select = document.getElementById('cbi.combobox.' + inputElement.id);
    if (!select) return;

    var target = String(value == null ? '' : value);
    var hasOption = false;
    for (var i = 0; i < select.options.length; i++) {
        if (select.options[i].value === target) {
            hasOption = true;
            break;
        }
    }

    if (hasOption) {
        select.value = target;
    } else {
        if (target === '') {
            select.value = '';
        } else {
            var option = document.createElement('option');
            option.value = target;
            option.text = target;

            var customOption = null;
            for (var j = 0; j < select.options.length; j++) {
                if (select.options[j].value === '') {
                    customOption = select.options[j];
                    break;
                }
            }

            if (customOption && customOption.parentNode) {
                customOption.parentNode.insertBefore(option, customOption);
            } else {
                select.appendChild(option);
            }
            select.value = target;
        }
    }

    dispatchFieldChange(select);
}

function tryExpandDynamicListRows(sid, field, targetCount) {
    var container = getDynamicListContainer(sid, field);
    if (!container) return false;

    var currentInputs = getDynamicListInputs(sid, field);
    if (currentInputs.length >= targetCount) return true;

    var buttons = container.querySelectorAll('img.cbi-image-button');
    if (!buttons || buttons.length === 0) return false;

    var clicked = false;
    for (var i = buttons.length - 1; i >= 0; i--) {
        var button = buttons[i];
        var src = String(button.getAttribute('src') || '').toLowerCase();
        if (src.indexOf('add.gif') !== -1) {
            button.click();
            clicked = true;
            break;
        }
    }

    return clicked;
}

function normalizeListValue(value) {
    var str = String(value == null ? '' : value).trim();
    if (str === '') return [];
    var parts = str.split(',');
    var result = [];
    for (var i = 0; i < parts.length; i++) {
        var item = parts[i].trim();
        if (item !== '') result.push(item);
    }
    return result;
}

function isMultiValueField(field) {
    return {
        alpn: true,
        ws_headers: true,
        http_headers: true,
        h2_host: true,
        http_path: true,
        dns: true,
        host_key: true,
        host_key_algorithms: true
    }[field] === true;
}

function setFormValue(sid, field, value, retry) {
    var retries = typeof retry === 'number' ? retry : 0;
    var multiValueField = isMultiValueField(field);
    var normalized = String(value == null ? '' : value);
    var listValues = normalizeListValue(normalized);

    if (multiValueField) {
        var targetCount = Math.max(1, listValues.length);
        var dynInputs = getDynamicListInputs(sid, field);

        if (dynInputs.length > 0 && dynInputs.length < targetCount && retries < 30) {
            tryExpandDynamicListRows(sid, field, targetCount);
            setTimeout(function() {
                setFormValue(sid, field, value, retries + 1);
            }, 60);
            return;
        }

        if (dynInputs.length > 0) {
            for (var idx = 0; idx < dynInputs.length; idx++) {
                var itemValue = idx < listValues.length ? listValues[idx] : '';
                setElementValue(dynInputs[idx], itemValue);
                syncDynamicListSelect(dynInputs[idx], itemValue);
            }
            return;
        }
    }

    var elements = getFormElements(sid, field);

    if ((!elements || elements.length === 0) && retries < 30) {
        setTimeout(function() {
            setFormValue(sid, field, value, retries + 1);
        }, 60);
        return;
    }

    if (!elements || elements.length === 0) return;

    if (multiValueField && elements.length > 1) {
        for (var i = 0; i < elements.length; i++) {
            setElementValue(elements[i], i < listValues.length ? listValues[i] : '');
        }
        return;
    }

    var primary = elements[0];
    for (var j = 0; j < elements.length; j++) {
        var candidate = elements[j];
        if (!candidate) continue;
        if ((candidate.type || '').toLowerCase() !== 'hidden') {
            primary = candidate;
            break;
        }
    }

    setElementValue(primary, normalized);
}

function decodeURIComponentSafe(value) {
    if (typeof value !== 'string') return value;
    try {
        return decodeURIComponent(value);
    } catch (e) {
        return value;
    }
}

function stripYamlQuotes(value) {
    var v = (value || '').trim();
    if (v.length >= 2) {
        var first = v.charAt(0);
        var last = v.charAt(v.length - 1);
        if ((first === '"' && last === '"') || (first === "'" && last === "'")) {
            return v.substring(1, v.length - 1);
        }
    }
    return v;
}

function encodeYamlScalar(value) {
    var v = value;
    if (typeof v === 'boolean' || typeof v === 'number') {
        return String(v);
    }
    v = String(v == null ? '' : v);
    if (/^(true|false|null)$/i.test(v) || /^-?\d+(\.\d+)?$/.test(v)) {
        return v;
    }
    return '"' + v.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';
}

function buildOtherParameterBlock(key, value) {
    var lines = [];
    if (Array.isArray(value)) {
        lines.push('    ' + key + ':');
        for (var i = 0; i < value.length; i++) {
            lines.push('      - ' + encodeYamlScalar(value[i]));
        }
    } else {
        lines.push('    ' + key + ': ' + encodeYamlScalar(value));
    }
    return lines;
}

function keepOnlyCommentLines(text) {
    var source = (text || '').replace(/\r\n?/g, '\n');
    var lines = source === '' ? [] : source.split('\n');
    var kept = [];
    for (var i = 0; i < lines.length; i++) {
        var line = lines[i];
        if (/^\s*$/.test(line) || /^\s*#/.test(line)) {
            kept.push(line);
        }
    }
    while (kept.length > 0 && /^\s*$/.test(kept[kept.length - 1])) {
        kept.pop();
    }
    return kept.join('\n');
}

var currentImportOtherParamsState = null;

function beginImportOtherParameters(sid) {
    var oldText = getFormValue(sid, 'other_parameters') || '';
    var cleaned = keepOnlyCommentLines(oldText);
    setFormValue(sid, 'other_parameters', cleaned);
    currentImportOtherParamsState = {
        sid: String(sid),
        commentsText: cleaned,
        params: {}
    };
}

function endImportOtherParameters() {
    currentImportOtherParamsState = null;
}

function rebuildOtherParametersFromState(state) {
    if (!state || !state.params) return '';
    var lines = [];
    for (var key in state.params) {
        if (!state.params.hasOwnProperty(key)) continue;
        var value = state.params[key];
        if (value == null || value === '') continue;
        var block = buildOtherParameterBlock(key, value);
        if (lines.length > 0) {
            lines.push('');
        }
        Array.prototype.push.apply(lines, block);
    }
    var paramsText = lines.join('\n');
    var commentsText = (state.commentsText || '').replace(/\r\n?/g, '\n').replace(/\n+$/, '');
    if (commentsText && paramsText) {
        return commentsText + '\n' + paramsText;
    }
    return commentsText || paramsText;
}

function upsertOtherParameterText(text, key, value) {
    var source = (text || '').replace(/\r\n?/g, '\n');
    var lines = source === '' ? [] : source.split('\n');
    var block = buildOtherParameterBlock(key, value);
    var keyRegex = new RegExp('^ {4}' + key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ':\\s*(.*)$');
    var topLevelRegex = /^ {4}[A-Za-z0-9_-]+:\s*(.*)$/;

    var start = -1;
    for (var i = 0; i < lines.length; i++) {
        if (keyRegex.test(lines[i])) {
            start = i;
            break;
        }
    }

    if (start === -1) {
        if (lines.length > 0 && lines[lines.length - 1] !== '') {
            lines.push('');
        }
        Array.prototype.push.apply(lines, block);
        return lines.join('\n').replace(/^\n+/, '').replace(/\n+$/, '');
    }

    var end = start + 1;
    for (; end < lines.length; end++) {
        var line = lines[end];
        if (topLevelRegex.test(line)) break;
        if (/^\S/.test(line)) break;
    }

    lines.splice.apply(lines, [start, end - start].concat(block));
    return lines.join('\n').replace(/^\n+/, '').replace(/\n+$/, '');
}

function mergeUnknownParamsToOtherParameters(sid, params) {
    if (!params) return;

    if (currentImportOtherParamsState && currentImportOtherParamsState.sid === String(sid)) {
        var hasStateChanges = false;
        for (var stateKey in params) {
            if (!params.hasOwnProperty(stateKey)) continue;
            var stateValue = params[stateKey];
            if (stateValue == null || stateValue === '') continue;
            currentImportOtherParamsState.params[stateKey] = stateValue;
            hasStateChanges = true;
        }
        if (hasStateChanges) {
            setFormValue(sid, 'other_parameters', rebuildOtherParametersFromState(currentImportOtherParamsState));
        }
        return;
    }

    var text = getFormValue(sid, 'other_parameters') || '';
    var hasChanges = false;
    for (var key in params) {
        if (!params.hasOwnProperty(key)) continue;
        var value = params[key];
        if (value == null || value === '') continue;
        text = upsertOtherParameterText(text, key, value);
        hasChanges = true;
    }
    if (hasChanges) {
        setFormValue(sid, 'other_parameters', text);
    }
}

function parseOtherParameters(text) {
    var source = (text || '').replace(/\r\n?/g, '\n');
    var lines = source === '' ? [] : source.split('\n');
    var map = {};
    var i = 0;

    while (i < lines.length) {
        var line = lines[i];
        var match = line.match(/^ {4}([A-Za-z0-9_-]+):\s*(.*)$/);
        if (!match) {
            i++;
            continue;
        }

        var key = match[1];
        var rest = (match[2] || '').trim();
        if (rest !== '') {
            if (rest.charAt(0) === '#') {
                i++;
                continue;
            }
            if (/^\[.*\]$/.test(rest)) {
                var body = rest.substring(1, rest.length - 1).trim();
                if (body === '') {
                    map[key] = [];
                } else {
                    var parts = body.split(',');
                    var arr = [];
                    for (var p = 0; p < parts.length; p++) {
                        arr.push(stripYamlQuotes(parts[p].trim()));
                    }
                    map[key] = arr;
                }
            } else {
                map[key] = stripYamlQuotes(rest);
            }
            i++;
            continue;
        }

        var arrValues = [];
        var j = i + 1;
        while (j < lines.length) {
            var arrMatch = lines[j].match(/^ {6}-\s*(.*)$/);
            if (arrMatch) {
                arrValues.push(stripYamlQuotes(arrMatch[1].trim()));
                j++;
                continue;
            }
            if (/^ {4}[A-Za-z0-9_-]+:\s*(.*)$/.test(lines[j]) || /^\S/.test(lines[j])) {
                break;
            }
            j++;
        }

        if (arrValues.length > 0) {
            map[key] = arrValues;
        }
        i = j;
    }

    return map;
}

function mergeOtherParametersToQuery(sid, queryMap, keyMap, skipKeys) {
    var otherText = getFormValue(sid, 'other_parameters') || '';
    var other = parseOtherParameters(otherText);
    for (var key in other) {
        if (!other.hasOwnProperty(key)) continue;
        if (skipKeys && skipKeys[key]) continue;
        var value = other[key];
        var mappedKey = keyMap && keyMap[key] ? keyMap[key] : key;
        if (Array.isArray(value)) {
            queryMap[mappedKey] = value.join(',');
        } else {
            queryMap[mappedKey] = value;
        }
    }
}

function queryMapToString(queryMap) {
    var query = [];
    for (var key in queryMap) {
        if (!queryMap.hasOwnProperty(key)) continue;
        var value = queryMap[key];
        if (value == null || value === '') continue;
        query.push(encodeURIComponent(key) + '=' + encodeURIComponent(String(value)));
    }
    return query.join('&');
}

function isYamlListLikeKey(key) {
    return {
        alpn: true,
        dns: true,
        'host-key': true,
        'host-key-algorithms': true
    }[key] === true;
}

function normalizeUnknownParamValueByKey(key, value) {
    if (!isYamlListLikeKey(key)) {
        return value;
    }

    if (Array.isArray(value)) {
        var normalizedList = [];
        for (var i = 0; i < value.length; i++) {
            var item = String(value[i] == null ? '' : value[i]).trim();
            if (item) normalizedList.push(item);
        }
        return normalizedList;
    }

    var raw = String(value == null ? '' : value);
    var parts = raw.split(',');
    var result = [];
    for (var j = 0; j < parts.length; j++) {
        var part = parts[j].trim();
        if (part) result.push(part);
    }
    return result;
}

function collectUnknownQueryParams(query, knownKeys) {
    var result = {};
    for (var key in query) {
        if (!query.hasOwnProperty(key)) continue;
        if (knownKeys && knownKeys[key]) continue;
        result[key] = normalizeUnknownParamValueByKey(key, decodeURIComponentSafe(query[key]));
    }
    return result;
}

function remapParamKeys(params, keyMap) {
    if (!params) return {};
    var result = {};
    for (var key in params) {
        if (!params.hasOwnProperty(key)) continue;
        var mappedKey = keyMap && keyMap[key] ? keyMap[key] : key;
        result[mappedKey] = normalizeUnknownParamValueByKey(mappedKey, params[key]);
    }
    return result;
}

function getDefaultOtherParamSkipKeys() {
    return {
        name: true,
        type: true,
        server: true,
        port: true,
        username: true,
        password: true,
        uuid: true,
        token: true
    };
}

function export_url(btn, urlname, sid) {
    var s = document.getElementById(urlname + '-status');
    if (!s) return false;

    var v_type = document.getElementsByName('cbid.openclash.' + sid + '.type')[0];
    if (!v_type) return false;

    var type = v_type.value.toLowerCase();
    var url = null;

    try {
        switch (type) {
            case "ss":
                url = exportSS(sid);
                break;
            case "ssr":
                url = exportSSR(sid);
                break;
            case "vmess":
                url = exportVmess(sid);
                break;
            case "vless":
                url = exportVless(sid);
                break;
            case "trojan":
                url = exportTrojan(sid);
                break;
            case "hysteria":
                url = exportHysteria(sid);
                break;
            case "hysteria2":
                url = exportHysteria2(sid);
                break;
            case "tuic":
                url = exportTuic(sid);
                break;
            case "socks5":
                url = exportSocks(sid);
                break;
            case "http":
                url = exportHttp(sid);
                break;
            case "anytls":
                url = exportAnyTLS(sid);
                break;
            case "mieru":
                url = exportMieru(sid);
                break;
            default:
                s.className = 'oc-status-err';
                s.textContent = '<%:Unsupported protocol type%>';
                return false;
        }

        if (url) {
            var textarea = document.createElement("textarea");
            textarea.textContent = url;
            textarea.style.position = "fixed";
            document.body.appendChild(textarea);
            textarea.select();
            try {
                document.execCommand("copy");
                s.className = 'oc-status-ok';
                s.textContent = '<%:Copy%>' + " " + type.toUpperCase() + " " + '<%:to clipboard successfully%>';
            } catch (ex) {
                s.className = 'oc-status-err';
                s.textContent = '<%:Unable to copy%>' + " " + type.toUpperCase() + " " + '<%:to clipboard%>';
            } finally {
                document.body.removeChild(textarea);
            }
        } else {
            s.className = 'oc-status-err';
            s.textContent = '<%:Export failed%>';
        }
    } catch (e) {
        s.className = 'oc-status-err';
        s.textContent = '<%:Export error%>';
        return false;
    }

    return false;
}

function getFormValue(sid, field) {
    if (isMultiValueField(field)) {
        var dynInputs = getDynamicListInputs(sid, field);
        if (dynInputs && dynInputs.length > 0) {
            var dynValues = [];
            for (var di = 0; di < dynInputs.length; di++) {
                var dynValue = getElementValue(dynInputs[di]);
                if (dynValue != null && dynValue !== '') {
                    dynValues.push(dynValue);
                }
            }
            return dynValues.join(',');
        }
    }

    var elements = getFormElements(sid, field);
    if (!elements || elements.length === 0) return '';
    if (elements.length === 1 || !isMultiValueField(field)) return getElementValue(elements[0]);

    var values = [];
    for (var i = 0; i < elements.length; i++) {
        var elementValue = getElementValue(elements[i]);
        if (elementValue != null && elementValue !== '') {
            values.push(elementValue);
        }
    }
    return values.join(',');
}

function exportSS(sid) {
    var server = getFormValue(sid, 'server');
    var port = getFormValue(sid, 'port');
    var password = getFormValue(sid, 'password');
    var cipher = getFormValue(sid, 'cipher');
    var name = getFormValue(sid, 'name');
    var obfs = getFormValue(sid, 'obfs');
    var host = getFormValue(sid, 'host');
    var path = getFormValue(sid, 'path');
    var tls = getFormValue(sid, 'tls');

    if (!server || !port || !password || !cipher) {
        return null;
    }

    // SIP002 format
    var userInfo = b64encsafe(cipher + ':' + password);
    var url = userInfo + '@' + server + ':' + port + '/?';

    var queryMap = {};

    if (obfs && obfs !== 'none') {
        var plugin = '';
        if (obfs === 'http' || obfs === 'tls') {
            plugin = 'obfs-local;obfs=' + obfs;
            if (host) {
                plugin += ';obfs-host=' + host;
            }
        } else if (obfs === 'websocket') {
            plugin = 'v2ray-plugin;mode=websocket';
            if (host) {
                plugin += ';host=' + host;
            }
            if (path) {
                plugin += ';path=' + path;
            }
            if (tls === 'true') {
                plugin += ';tls=true';
            }
        }
        if (plugin) {
            queryMap.plugin = plugin;
        }
    }

    if (getFormValue(sid, 'udp_over_tcp') === 'true') {
        queryMap.uot = '1';
    }

    mergeOtherParametersToQuery(sid, queryMap, null, getDefaultOtherParamSkipKeys());
    url += queryMapToString(queryMap);

    if (name) {
        url += '#' + encodeURIComponent(name);
    }

    return 'ss://' + url;
}

function exportSSR(sid) {
    var server = getFormValue(sid, 'server');
    var port = getFormValue(sid, 'port');
    var protocol = getFormValue(sid, 'protocol');
    var method = getFormValue(sid, 'cipher');
    var obfs = getFormValue(sid, 'obfs_ssr');
    var password = getFormValue(sid, 'password');
    var obfs_param = getFormValue(sid, 'obfs_param');
    var protocol_param = getFormValue(sid, 'protocol_param');
    var name = getFormValue(sid, 'name');

    if (!server || !port || !password || !method) {
        return null;
    }

    var queryMap = {
        obfsparam: b64encsafe(obfs_param || ''),
        protoparam: b64encsafe(protocol_param || ''),
        remarks: b64encutf8safe(name || '')
    };
    mergeOtherParametersToQuery(sid, queryMap, null, getDefaultOtherParamSkipKeys());

    var ssr_str = server + ":" + port + ":" + protocol + ":" + method + ":" + obfs + ":" +
                  b64encsafe(password) + "/?" + queryMapToString(queryMap);

    return "ssr://" + b64encsafe(ssr_str);
}

function exportVmess(sid) {
    var server = getFormValue(sid, 'server');
    var port = getFormValue(sid, 'port');
    var uuid = getFormValue(sid, 'uuid');
    var alterId = getFormValue(sid, 'alterId');
    var security = getFormValue(sid, 'cipher');
    var name = getFormValue(sid, 'name');
    var obfs = getFormValue(sid, 'obfs_vmess');
    var tls = getFormValue(sid, 'tls');
    var servername = getFormValue(sid, 'servername');
    var clientFingerprint = getFormValue(sid, 'client_fingerprint');

    if (!server || !port || !uuid) {
        return null;
    }

    var info = {
        "v": "2",
        "ps": name || "",
        "add": server,
        "port": port,
        "id": uuid,
        "aid": alterId || "0",
        "scy": security || "auto",
        "net": "tcp",
        "type": "none",
        "host": "",
        "path": "",
        "tls": tls === 'true' ? "tls" : ""
    };

    if (tls === 'true' && servername) {
        info.sni = servername;
    }

    if (clientFingerprint) {
        info.fp = clientFingerprint;
    }

    // Handle network type
    if (obfs === 'websocket') {
        info.net = "ws";
        info.path = getFormValue(sid, 'ws_path') || '/';
        var headers = getFormValue(sid, 'ws_headers');
        if (headers && headers.includes('Host:')) {
            info.host = headers.split('Host:')[1].trim();
        }
    } else if (obfs === 'h2') {
        info.net = "h2";
        info.path = getFormValue(sid, 'h2_path') || '/';
        info.host = getFormValue(sid, 'h2_host') || '';
    } else if (obfs === 'grpc') {
        info.net = "grpc";
        info.path = getFormValue(sid, 'grpc_service_name') || '';
    }

    var other = parseOtherParameters(getFormValue(sid, 'other_parameters') || '');
    for (var key in other) {
        if (!other.hasOwnProperty(key)) continue;
        if (getDefaultOtherParamSkipKeys()[key]) continue;
        var val = other[key];
        if (Array.isArray(val)) {
            info[key] = val.join(',');
        } else {
            info[key] = val;
        }
    }

    return "vmess://" + b64EncodeUnicode(JSON.stringify(info));
}

function exportVless(sid) {
    var server = getFormValue(sid, 'server');
    var port = getFormValue(sid, 'port');
    var uuid = getFormValue(sid, 'uuid');
    var name = getFormValue(sid, 'name');
    var tls = getFormValue(sid, 'tls');
    var servername = getFormValue(sid, 'servername');
    var obfs = getFormValue(sid, 'obfs_vless');
    var flow = getFormValue(sid, 'vless_flow');
    var encryption = getFormValue(sid, 'vless_encryption');
    var clientFingerprint = getFormValue(sid, 'client_fingerprint');
    var realityPublicKey = getFormValue(sid, 'reality_public_key');
    var realityShortId = getFormValue(sid, 'reality_short_id');

    if (!server || !port || !uuid) {
        return null;
    }

    var url = uuid + '@' + server + ':' + port + '?';
    var queryMap = {};
    if (obfs === 'tcp') {
        queryMap.encryption = encryption || 'none';
    }

    if (tls === 'true') {
        if (realityPublicKey || realityShortId) {
            queryMap.security = 'reality';
        }
        if (flow && flow.includes('xtls')) {
            queryMap.security = 'xtls';
            queryMap.flow = flow;
        } else {
            queryMap.security = queryMap.security || 'tls';
        }
        if (servername) {
            queryMap.sni = servername;
        }
    }

    if (clientFingerprint) {
        queryMap.fp = clientFingerprint;
    }

    if (realityPublicKey) {
        queryMap.pbk = realityPublicKey;
    }

    if (realityShortId) {
        queryMap.sid = realityShortId;
    }

    if (obfs === 'ws') {
        queryMap.type = 'ws';
        var path = getFormValue(sid, 'ws_path');
        if (path) {
            queryMap.path = path;
        }
        var headers = getFormValue(sid, 'ws_headers');
        if (headers && headers.includes('Host:')) {
            var host = headers.split('Host:')[1].trim();
            queryMap.host = host;
        }
    } else if (obfs === 'grpc') {
        queryMap.type = 'grpc';
        var serviceName = getFormValue(sid, 'grpc_service_name');
        if (serviceName) {
            queryMap.serviceName = serviceName;
        }
    } else if (obfs === 'xhttp') {
        queryMap.type = 'xhttp';
        var xhttpPath = getFormValue(sid, 'xhttp_opts_path');
        var xhttpHost = getFormValue(sid, 'xhttp_opts_host');
        if (xhttpPath) queryMap.path = xhttpPath;
        if (xhttpHost) queryMap.host = xhttpHost;
    } else {
        queryMap.type = 'tcp';
    }

    mergeOtherParametersToQuery(sid, queryMap, {
        'client-fingerprint': 'fp',
        'public-key': 'pbk',
        'short-id': 'sid',
        'grpc-service-name': 'serviceName'
    }, getDefaultOtherParamSkipKeys());
    url += queryMapToString(queryMap);

    if (name) {
        url += '#' + encodeURIComponent(name);
    }

    return 'vless://' + url;
}

function exportTrojan(sid) {
    var server = getFormValue(sid, 'server');
    var port = getFormValue(sid, 'port');
    var password = getFormValue(sid, 'password');
    var name = getFormValue(sid, 'name');
    var sni = getFormValue(sid, 'sni');
    var alpn = getFormValue(sid, 'alpn');
    var skip_cert = getFormValue(sid, 'skip_cert_verify');
    var obfs = getFormValue(sid, 'obfs_trojan');
    var fingerprint = getFormValue(sid, 'fingerprint');

    if (!server || !port || !password) {
        return null;
    }

    var url = encodeURIComponent(password) + '@' + server + ':' + port + '/?';
    var queryMap = {};

    if (sni) {
        queryMap.sni = sni;
    }

    if (alpn) {
        queryMap.alpn = alpn;
    }

    if (obfs === 'ws') {
        queryMap.type = 'ws';
        var wsPath = getFormValue(sid, 'ws_path');
        var wsHeaders = getFormValue(sid, 'ws_headers');
        if (wsPath) queryMap.path = wsPath;
        if (wsHeaders && wsHeaders.indexOf('Host:') !== -1) {
            queryMap.host = wsHeaders.split('Host:')[1].trim();
        }
    } else if (obfs === 'grpc') {
        queryMap.type = 'grpc';
        var grpcServiceName = getFormValue(sid, 'grpc_service_name');
        if (grpcServiceName) queryMap.serviceName = grpcServiceName;
    }

    if (skip_cert === 'true') {
        queryMap.allowInsecure = '1';
    }

    if (fingerprint) {
        queryMap.pcs = fingerprint;
    }

    mergeOtherParametersToQuery(sid, queryMap, {
        'client-fingerprint': 'fp',
        'grpc-service-name': 'serviceName'
    }, getDefaultOtherParamSkipKeys());
    url += queryMapToString(queryMap);

    if (name) {
        url += '#' + encodeURIComponent(name);
    }

    return 'trojan://' + url;
}

function exportHysteria(sid) {
    var server = getFormValue(sid, 'server');
    var port = getFormValue(sid, 'port');
    var auth = getFormValue(sid, 'hysteria_auth_str');
    var name = getFormValue(sid, 'name');
    var protocol = getFormValue(sid, 'hysteria_protocol');
    var up = getFormValue(sid, 'hysteria_up');
    var down = getFormValue(sid, 'hysteria_down');
    var obfs = getFormValue(sid, 'hysteria_obfs');
    var sni = getFormValue(sid, 'sni');
    var alpn = getFormValue(sid, 'alpn');
    var skip_cert = getFormValue(sid, 'skip_cert_verify');
    var ports = getFormValue(sid, 'ports');
    var hopInterval = getFormValue(sid, 'hop_interval');
    var recvWindowConn = getFormValue(sid, 'recv_window_conn');
    var recvWindow = getFormValue(sid, 'recv_window');
    var disableMtuDiscovery = getFormValue(sid, 'disable_mtu_discovery');
    var fastOpen = getFormValue(sid, 'fast_open');
    var fingerprint = getFormValue(sid, 'fingerprint');

    if (!server || !port) {
        return null;
    }

    var url = server + ':' + port + '?';
    var queryMap = {};

    if (auth) {
        queryMap.auth = auth;
    }

    if (protocol) {
        queryMap.protocol = protocol;
    }

    if (up) {
        queryMap.up = up;
    }

    if (down) {
        queryMap.down = down;
    }

    if (obfs) {
        queryMap.obfs = obfs;
    }

    if (sni) {
        queryMap.peer = sni;
    }

    if (alpn) {
        queryMap.alpn = alpn;
    }

    if (skip_cert === 'true') {
        queryMap.insecure = '1';
    }

    if (ports) {
        queryMap.ports = ports;
    }

    if (hopInterval) {
        queryMap['hop-interval'] = hopInterval;
    }

    if (recvWindowConn) {
        queryMap['recv-window-conn'] = recvWindowConn;
    }

    if (recvWindow) {
        queryMap['recv-window'] = recvWindow;
    }

    if (disableMtuDiscovery === 'true') {
        queryMap['disable-mtu-discovery'] = '1';
    }

    if (fastOpen === 'true') {
        queryMap['fast-open'] = '1';
    }

    if (fingerprint) {
        queryMap.fingerprint = fingerprint;
    }

    mergeOtherParametersToQuery(sid, queryMap, {
        sni: 'peer',
        'auth-str': 'auth',
        'obfs-param': 'obfsParam'
    }, getDefaultOtherParamSkipKeys());
    url += queryMapToString(queryMap);

    if (name) {
        url += '#' + encodeURIComponent(name);
    }

    return 'hysteria://' + url;
}

function exportHysteria2(sid) {
    var server = getFormValue(sid, 'server');
    var port = getFormValue(sid, 'port');
    var password = getFormValue(sid, 'password');
    var name = getFormValue(sid, 'name');
    var obfs = getFormValue(sid, 'hysteria_obfs');
    var obfs_password = getFormValue(sid, 'obfs_password');
    var up = getFormValue(sid, 'hysteria_up');
    var down = getFormValue(sid, 'hysteria_down');
    var sni = getFormValue(sid, 'sni');
    var alpn = getFormValue(sid, 'alpn');
    var skip_cert = getFormValue(sid, 'skip_cert_verify');
    var fingerprint = getFormValue(sid, 'fingerprint');
    var ports = getFormValue(sid, 'ports');
    var hopInterval = getFormValue(sid, 'hop_interval');
    var initialStreamReceiveWindow = getFormValue(sid, 'initial_stream_receive_window');
    var maxStreamReceiveWindow = getFormValue(sid, 'max_stream_receive_window');
    var initialConnectionReceiveWindow = getFormValue(sid, 'initial_connection_receive_window');
    var maxConnectionReceiveWindow = getFormValue(sid, 'max_connection_receive_window');

    if (!server || !port) {
        return null;
    }

    var url = '';
    if (password) {
        url += encodeURIComponent(password) + '@';
    }
    url += server + ':' + port + '?';

    var queryMap = {};

    if (obfs) {
        queryMap.obfs = obfs;
    }

    if (obfs_password) {
        queryMap['obfs-password'] = obfs_password;
    }

    if (up) {
        queryMap.up = up;
    }

    if (down) {
        queryMap.down = down;
    }

    if (sni) {
        queryMap.sni = sni;
    }

    if (alpn) {
        queryMap.alpn = alpn;
    }

    if (skip_cert === 'true') {
        queryMap.insecure = '1';
    }

    if (fingerprint) {
        queryMap.pinSHA256 = fingerprint;
    }

    if (ports) {
        queryMap.ports = ports;
    }

    if (hopInterval) {
        queryMap['hop-interval'] = hopInterval;
    }

    if (initialStreamReceiveWindow) {
        queryMap['initial-stream-receive-window'] = initialStreamReceiveWindow;
    }

    if (maxStreamReceiveWindow) {
        queryMap['max-stream-receive-window'] = maxStreamReceiveWindow;
    }

    if (initialConnectionReceiveWindow) {
        queryMap['initial-connection-receive-window'] = initialConnectionReceiveWindow;
    }

    if (maxConnectionReceiveWindow) {
        queryMap['max-connection-receive-window'] = maxConnectionReceiveWindow;
    }

    mergeOtherParametersToQuery(sid, queryMap, {
        fingerprint: 'pinSHA256'
    }, getDefaultOtherParamSkipKeys());
    url += queryMapToString(queryMap);

    if (name) {
        url += '#' + encodeURIComponent(name);
    }

    return 'hysteria2://' + url;
}

function exportTuic(sid) {
    var server = getFormValue(sid, 'server');
    var port = getFormValue(sid, 'port');
    var uuid = getFormValue(sid, 'uuid');
    var password = getFormValue(sid, 'password');
    var token = getFormValue(sid, 'token');
    var name = getFormValue(sid, 'name');
    var cc = getFormValue(sid, 'congestion_controller');
    var alpn = getFormValue(sid, 'alpn');
    var sni = getFormValue(sid, 'sni');
    var disable_sni = getFormValue(sid, 'disable_sni');
    var udp_relay = getFormValue(sid, 'udp_relay_mode');
    var reduce_rtt = getFormValue(sid, 'reduce_rtt');
    var heartbeat_interval = getFormValue(sid, 'heartbeat_interval');
    var request_timeout = getFormValue(sid, 'request_timeout');
    var max_udp_relay_packet_size = getFormValue(sid, 'max_udp_relay_packet_size');
    var max_open_streams = getFormValue(sid, 'max_open_streams');
    var fast_open = getFormValue(sid, 'fast_open');
    var skip_cert = getFormValue(sid, 'skip_cert_verify');

    if (!server || !port) {
        return null;
    }

    var url = '';
    if (password) {
        // TUIC v5
        url += encodeURIComponent(uuid) + ':' + encodeURIComponent(password) + '@';
    } else if (token) {
        // TUIC v4
        url += encodeURIComponent(token) + '@';
    }

    url += server + ':' + port + '?';

    var queryMap = {};

    if (cc) {
        queryMap.congestion_control = cc;
    }

    if (alpn) {
        queryMap.alpn = alpn;
    }

    if (sni) {
        queryMap.sni = sni;
    }

    if (disable_sni === 'true') {
        queryMap.disable_sni = '1';
    }

    if (udp_relay) {
        queryMap.udp_relay_mode = udp_relay;
    }

    if (reduce_rtt === 'true') {
        queryMap.reduce_rtt = '1';
    }

    if (heartbeat_interval) {
        queryMap['heartbeat-interval'] = heartbeat_interval;
    }

    if (request_timeout) {
        queryMap['request-timeout'] = request_timeout;
    }

    if (max_udp_relay_packet_size) {
        queryMap['max-udp-relay-packet-size'] = max_udp_relay_packet_size;
    }

    if (max_open_streams) {
        queryMap['max-open-streams'] = max_open_streams;
    }

    if (fast_open) {
        queryMap['fast-open'] = fast_open;
    }

    if (skip_cert) {
        queryMap['skip-cert-verify'] = skip_cert;
    }

    mergeOtherParametersToQuery(sid, queryMap, {
        'congestion-controller': 'congestion_control',
        'disable-sni': 'disable_sni',
        'udp-relay-mode': 'udp_relay_mode',
        'reduce-rtt': 'reduce_rtt'
    }, getDefaultOtherParamSkipKeys());
    url += queryMapToString(queryMap);

    if (name) {
        url += '#' + encodeURIComponent(name);
    }

    return 'tuic://' + url;
}

function exportSocks(sid) {
    var server = getFormValue(sid, 'server');
    var port = getFormValue(sid, 'port');
    var username = getFormValue(sid, 'username');
    var password = getFormValue(sid, 'password');
    var name = getFormValue(sid, 'name');

    if (!server || !port) {
        return null;
    }

    var url = '';
    if (username && password) {
        url += encodeURIComponent(username) + ':' + encodeURIComponent(password) + '@';
    }
    url += server + ':' + port;

    var queryMap = {};
    mergeOtherParametersToQuery(sid, queryMap, null, getDefaultOtherParamSkipKeys());
    var queryString = queryMapToString(queryMap);

    if (queryString) {
        url += '?' + queryString;
    }

    if (name) {
        url += '#' + encodeURIComponent(name);
    }

    return 'socks5://' + url;
}

function exportHttp(sid) {
    var server = getFormValue(sid, 'server');
    var port = getFormValue(sid, 'port');
    var username = getFormValue(sid, 'username');
    var password = getFormValue(sid, 'password');
    var name = getFormValue(sid, 'name');
    var tls = getFormValue(sid, 'tls');

    if (!server || !port) {
        return null;
    }

    var scheme = tls === 'true' ? 'https' : 'http';
    var url = '';

    if (username && password) {
        url += encodeURIComponent(username) + ':' + encodeURIComponent(password) + '@';
    }
    url += server + ':' + port;

    var queryMap = {};
    mergeOtherParametersToQuery(sid, queryMap, null, getDefaultOtherParamSkipKeys());
    var queryString = queryMapToString(queryMap);

    if (queryString) {
        url += '?' + queryString;
    }

    if (name) {
        url += '#' + encodeURIComponent(name);
    }

    return scheme + '://' + url;
}

function exportAnyTLS(sid) {
    var server = getFormValue(sid, 'server');
    var port = getFormValue(sid, 'port');
    var password = getFormValue(sid, 'password');
    var name = getFormValue(sid, 'name');
    var sni = getFormValue(sid, 'sni');
    var clientFingerprint = getFormValue(sid, 'client_fingerprint');
    var udp = getFormValue(sid, 'udp');
    var idleSessionCheckInterval = getFormValue(sid, 'idle_session_check_interval');
    var idleSessionTimeout = getFormValue(sid, 'idle_session_timeout');
    var minIdleSession = getFormValue(sid, 'min_idle_session');
    var skip_cert = getFormValue(sid, 'skip_cert_verify');
    var alpn = getFormValue(sid, 'alpn');
    var username = '';
    var other = parseOtherParameters(getFormValue(sid, 'other_parameters') || '');

    if (other.hasOwnProperty('username')) {
        username = Array.isArray(other.username) ? String(other.username[0] || '') : String(other.username || '');
    }

    if (!server || !port) {
        return null;
    }

    var url = '';
    if (username) {
        url += encodeURIComponent(username);
        if (password) {
            url += ':' + encodeURIComponent(password);
        }
        url += '@';
    }
    url += server + ':' + port + '?';

    var queryMap = {};

    if (sni) {
        queryMap.sni = sni;
    }

    if (skip_cert === 'true') {
        queryMap.insecure = '1';
    }

    if (alpn) {
        queryMap.alpn = alpn;
    }

    if (clientFingerprint) {
        queryMap['client-fingerprint'] = clientFingerprint;
    }

    if (udp) {
        queryMap.udp = udp;
    }

    if (idleSessionCheckInterval) {
        queryMap['idle-session-check-interval'] = idleSessionCheckInterval;
    }

    if (idleSessionTimeout) {
        queryMap['idle-session-timeout'] = idleSessionTimeout;
    }

    if (minIdleSession) {
        queryMap['min-idle-session'] = minIdleSession;
    }

    mergeOtherParametersToQuery(sid, queryMap, {
        fingerprint: 'hpkp'
    }, getDefaultOtherParamSkipKeys());
    url += queryMapToString(queryMap);

    if (name) {
        url += '#' + encodeURIComponent(name);
    }

    return 'anytls://' + url;
}

function exportMieru(sid) {
    var server = getFormValue(sid, 'server');
    var username = getFormValue(sid, 'username');
    var password = getFormValue(sid, 'password');
    var name = getFormValue(sid, 'name');
    var transport = getFormValue(sid, 'transport') || 'TCP';
    var multiplexing = getFormValue(sid, 'multiplexing');
    var port = getFormValue(sid, 'port');
    var portRange = getFormValue(sid, 'port_range');

    if (!server || !username || !password || (!port && !portRange)) {
        return null;
    }

    var url = encodeURIComponent(username) + ':' + encodeURIComponent(password) + '@' + server + '?';
    var queryMap = {};

    if (portRange) {
        var rangeParts = portRange.split(',');
        var rangeItems = [];
        for (var i = 0; i < rangeParts.length; i++) {
            var item = rangeParts[i].trim();
            if (item) rangeItems.push(item);
        }
        if (rangeItems.length > 0) {
            queryMap.port = rangeItems.join(',');
            queryMap.protocol = rangeItems.map(function () { return transport; }).join(',');
        }
    } else {
        queryMap.port = port;
        queryMap.protocol = transport;
    }

    if (multiplexing) {
        queryMap.multiplexing = multiplexing;
    }

    mergeOtherParametersToQuery(sid, queryMap, null, getDefaultOtherParamSkipKeys());
    url += queryMapToString(queryMap);

    if (name) {
        url += '#' + encodeURIComponent(name);
    }

    return 'mierus://' + url;
}

function import_url(btn, urlname, sid) {
    var s = document.getElementById(urlname + '-status');
    if (!s) return false;

    var ssrurl = prompt('<%:Paste sharing link here%>', "");
    if (ssrurl == null || ssrurl == "") {
        s.className = 'oc-status-err';
        s.textContent = '<%:User cancelled%>';
        return false;
    }
    s.textContent = '';
    s.className = '';

    var ssu = ssrurl.split('://');
    if (ssu.length < 2) {
        s.className = 'oc-status-err';
        s.textContent = '<%:Invalid format%>';
        return false;
    }

    var scheme = ssu[0].toLowerCase();
    var event = document.createEvent("HTMLEvents");
    event.initEvent("change", true, true);

    beginImportOtherParameters(sid);

    try {
        switch (scheme) {
            case "ss":
                if (parseSS(ssu[1], sid)) {
                    s.className = 'oc-status-ok';
                    s.textContent = '<%:Import configuration information successfully%>';
                } else {
                    s.className = 'oc-status-err';
                    s.textContent = '<%:Invalid format%>';
                }
                break;

            case "ssr":
                if (parseSSR(ssu[1], sid)) {
                    s.className = 'oc-status-ok';
                    s.textContent = '<%:Import configuration information successfully%>';
                } else {
                    s.className = 'oc-status-err';
                    s.textContent = '<%:Invalid format%>';
                }
                break;

            case "vmess":
                if (parseVmess(ssu[1], sid)) {
                    s.className = 'oc-status-ok';
                    s.textContent = '<%:Import configuration information successfully%>';
                } else {
                    s.className = 'oc-status-err';
                    s.textContent = '<%:Invalid format%>';
                }
                break;

            case "vless":
                if (parseVless(ssrurl, sid)) {
                    s.className = 'oc-status-ok';
                    s.textContent = '<%:Import configuration information successfully%>';
                } else {
                    s.className = 'oc-status-err';
                    s.textContent = '<%:Invalid format%>';
                }
                break;

            case "trojan":
                if (parseTrojan(ssrurl, sid)) {
                    s.className = 'oc-status-ok';
                    s.textContent = '<%:Import configuration information successfully%>';
                } else {
                    s.className = 'oc-status-err';
                    s.textContent = '<%:Invalid format%>';
                }
                break;

            case "hysteria":
                if (parseHysteria(ssrurl, sid)) {
                    s.className = 'oc-status-ok';
                    s.textContent = '<%:Import configuration information successfully%>';
                } else {
                    s.className = 'oc-status-err';
                    s.textContent = '<%:Invalid format%>';
                }
                break;

            case "hysteria2":
            case "hy2":
                if (parseHysteria2(ssrurl, sid)) {
                    s.className = 'oc-status-ok';
                    s.textContent = '<%:Import configuration information successfully%>';
                } else {
                    s.className = 'oc-status-err';
                    s.textContent = '<%:Invalid format%>';
                }
                break;

            case "tuic":
                if (parseTuic(ssrurl, sid)) {
                    s.className = 'oc-status-ok';
                    s.textContent = '<%:Import configuration information successfully%>';
                } else {
                    s.className = 'oc-status-err';
                    s.textContent = '<%:Invalid format%>';
                }
                break;

            case "socks":
            case "socks5":
            case "socks5h":
                if (parseSocks(ssrurl, sid)) {
                    s.className = 'oc-status-ok';
                    s.textContent = '<%:Import configuration information successfully%>';
                } else {
                    s.className = 'oc-status-err';
                    s.textContent = '<%:Invalid format%>';
                }
                break;

            case "http":
            case "https":
                if (parseHttp(ssrurl, sid)) {
                    s.className = 'oc-status-ok';
                    s.textContent = '<%:Import configuration information successfully%>';
                } else {
                    s.className = 'oc-status-err';
                    s.textContent = '<%:Invalid format%>';
                }
                break;

            case "anytls":
                if (parseAnyTLS(ssrurl, sid)) {
                    s.className = 'oc-status-ok';
                    s.textContent = '<%:Import configuration information successfully%>';
                } else {
                    s.className = 'oc-status-err';
                    s.textContent = '<%:Invalid format%>';
                }
                break;

            case "mierus":
                if (parseMieru(ssrurl, sid)) {
                    s.className = 'oc-status-ok';
                    s.textContent = '<%:Import configuration information successfully%>';
                } else {
                    s.className = 'oc-status-err';
                    s.textContent = '<%:Invalid format%>';
                }
                break;

            default:
                s.className = 'oc-status-err';
                s.textContent = '<%:Invalid format%>';
                endImportOtherParameters();
                return false;
        }
    } catch (e) {
        s.className = 'oc-status-err';
        s.textContent = '<%:Parse error%>';
        endImportOtherParameters();
        return false;
    }

    endImportOtherParameters();

    return false;
}

function parseSS(body, sid) {
    var url0, param = "";
    var sipIndex = body.indexOf("@");
    var ploc = body.indexOf("#");

    if (ploc > 0) {
        url0 = body.substr(0, ploc);
        param = body.substr(ploc + 1);
    } else {
        url0 = body;
    }

    setFormValue(sid, 'type', 'ss');

    if (sipIndex !== -1) {
        // SIP002 format
        var userInfo = b64decsafe(url0.substr(0, sipIndex));
        var temp = url0.substr(sipIndex + 1).split("/?");
        var serverInfo = temp[0].split(":");
        var server = serverInfo[0];
        var port = serverInfo[1];
        var method, password;

        if (temp[1]) {
            var query = parseQuery("?" + temp[1]);
            var knownQueryKeys = {
                plugin: true,
                'udp-over-tcp': true,
                uot: true
            };

            if (query.plugin) {
                var decodedPlugin = decodeURIComponent(query.plugin);

                var pluginParts = decodedPlugin.split(';');
                var pluginName = pluginParts[0];

                // obfs-local
                if (pluginName === 'obfs-local' || pluginName.includes('obfs')) {
                    var obfsMode = 'http';
                    var obfsHost = '';

                    for (var i = 1; i < pluginParts.length; i++) {
                        var opt = pluginParts[i];
                        var eqIndex = opt.indexOf('=');
                        if (eqIndex !== -1) {
                            var key = opt.substring(0, eqIndex).trim();
                            var value = opt.substring(eqIndex + 1).trim();

                            if (key === 'obfs') {
                                obfsMode = value;
                            } else if (key === 'obfs-host') {
                                obfsHost = value;
                            }
                        }
                    }

                    setFormValue(sid, 'obfs', obfsMode);
                    if (obfsHost) {
                        setFormValue(sid, 'host', obfsHost);
                    }
                }

                // v2ray-plugin
                if (pluginName === 'v2ray-plugin') {
                    var v2rayMode = 'websocket';
                    var v2rayHost = '';
                    var v2rayPath = '/';
                    var v2rayTls = false;

                    for (var i = 1; i < pluginParts.length; i++) {
                        var opt = pluginParts[i];
                        var eqIndex = opt.indexOf('=');
                        if (eqIndex !== -1) {
                            var key = opt.substring(0, eqIndex).trim();
                            var value = opt.substring(eqIndex + 1).trim();

                            if (key === 'mode') {
                                v2rayMode = value;
                            } else if (key === 'host') {
                                v2rayHost = value;
                            } else if (key === 'path') {
                                v2rayPath = value;
                            } else if (key === 'tls') {
                                v2rayTls = value === 'true' || value === '1';
                            }
                        }
                    }

                    setFormValue(sid, 'obfs', 'websocket');
                    if (v2rayHost) {
                        setFormValue(sid, 'host', v2rayHost);
                    }
                    if (v2rayPath) {
                        setFormValue(sid, 'path', v2rayPath);
                    }
                    if (v2rayTls) {
                        setFormValue(sid, 'tls', 'true');
                    }
                }
            }

            if (query['udp-over-tcp'] === 'true' || query['uot'] === '1') {
                setFormValue(sid, 'udp_over_tcp', 'true');
            }

            mergeUnknownParamsToOtherParameters(sid, collectUnknownQueryParams(query, knownQueryKeys));
        }

        var userInfoSplitIndex = userInfo.indexOf(":");
        if (userInfoSplitIndex !== -1) {
            method = userInfo.substr(0, userInfoSplitIndex);
            password = userInfo.substr(userInfoSplitIndex + 1);
        }

        setFormValue(sid, 'server', server);
        setFormValue(sid, 'port', port);
        setFormValue(sid, 'password', password || "");
        setFormValue(sid, 'cipher', method || "");
    } else {
        // Legacy format
        var sstr = b64decsafe(url0);
        var team = sstr.split('@');
        var part1 = team[0].split(':');
        var part2 = team[1].split(':');

        setFormValue(sid, 'server', part2[0]);
        setFormValue(sid, 'port', part2[1]);
        setFormValue(sid, 'password', part1[1]);
        setFormValue(sid, 'cipher', part1[0]);
    }

    if (param) {
        setFormValue(sid, 'name', decodeURIComponent(param));
    }

    return true;
}

function parseSSR(body, sid) {
    var dcBuf;
    try {
        dcBuf = b64decsafe(body);
    } catch (e) {
        return false;
    }

    setFormValue(sid, 'type', 'ssr');

    // ssr://host:port:protocol:method:obfs:urlsafebase64pass/?obfsparam=...
    var before, after;
    var queryIndex = dcBuf.indexOf('/?');
    if (queryIndex > 0) {
        before = dcBuf.substr(0, queryIndex);
        after = dcBuf.substr(queryIndex + 2);
    } else {
        before = dcBuf;
        after = "";
    }

    var parts = before.split(':');
    if (parts.length !== 6) {
        return false;
    }

    var host = parts[0];
    var port = parts[1];
    var protocol = parts[2];
    var method = parts[3];
    var obfs = parts[4];
    var password = b64decsafe(parts[5]);

    setFormValue(sid, 'server', host);
    setFormValue(sid, 'port', port);
    setFormValue(sid, 'protocol', protocol);
    setFormValue(sid, 'cipher', method);
    setFormValue(sid, 'obfs_ssr', obfs);
    setFormValue(sid, 'password', password);

    if (after) {
        var params = {};
        var paramPairs = after.split('&');
        for (var i = 0; i < paramPairs.length; i++) {
            var pair = paramPairs[i].split('=');
            if (pair.length === 2) {
                var key = decodeURIComponent(pair[0]);
                var value = pair[1];
                params[key] = value;
            }
        }

        if (params.obfsparam) {
            setFormValue(sid, 'obfs_param', b64decsafe(params.obfsparam));
        }

        if (params.protoparam) {
            setFormValue(sid, 'protocol_param', b64decsafe(params.protoparam));
        }

        if (params.remarks) {
            setFormValue(sid, 'name', b64decutf8safe(params.remarks));
        }

        mergeUnknownParamsToOtherParameters(sid, collectUnknownQueryParams(params, {
            obfsparam: true,
            protoparam: true,
            remarks: true
        }));
    }

    return true;
}

function parseVmess(body, sid) {
    try {
        // Try V2rayN format first
        var sstr = b64DecodeUnicode(body);
        var ssm = JSON.parse(sstr);

        setFormValue(sid, 'type', 'vmess');
        setFormValue(sid, 'name', ssm.ps || '');
        setFormValue(sid, 'server', ssm.add);
        setFormValue(sid, 'port', ssm.port);
        setFormValue(sid, 'alterId', ssm.aid || 0);
        setFormValue(sid, 'uuid', ssm.id);

        if (ssm.scy) {
            setFormValue(sid, 'cipher', ssm.scy);
        }

        if (ssm.tls === "tls") {
            setFormValue(sid, 'tls', 'true');
            if (ssm.sni) {
                setFormValue(sid, 'servername', ssm.sni);
            }
        }

        if (ssm.fp) {
            setFormValue(sid, 'client_fingerprint', ssm.fp);
        }

        var network = (ssm.net || 'tcp').toLowerCase();
        if (network === 'ws') {
            setFormValue(sid, 'obfs_vmess', 'websocket');
            setFormValue(sid, 'ws_path', ssm.path || '/');
            if (ssm.host) {
                setFormValue(sid, 'ws_headers', 'Host: ' + ssm.host);
            }
        } else if (network === 'h2') {
            setFormValue(sid, 'obfs_vmess', 'h2');
            setFormValue(sid, 'h2_path', ssm.path || '/');
            if (ssm.host) {
                setFormValue(sid, 'h2_host', ssm.host);
            }
        } else if (network === 'tcp') {
            if (ssm.type === 'http') {
                setFormValue(sid, 'obfs_vmess', 'http');
                if (ssm.path) {
                    setFormValue(sid, 'http_path', ssm.path);
                }
                if (ssm.host) {
                    mergeUnknownParamsToOtherParameters(sid, {
                        host: ssm.host
                    });
                }
            } else {
                setFormValue(sid, 'obfs_vmess', 'none');
            }
        } else if (network === 'grpc') {
            setFormValue(sid, 'obfs_vmess', 'grpc');
            setFormValue(sid, 'grpc_service_name', ssm.path || '');
        }

        var knownVmessJsonKeys = {
            v: true,
            ps: true,
            add: true,
            port: true,
            id: true,
            aid: true,
            scy: true,
            net: true,
            type: true,
            host: true,
            path: true,
            tls: true,
            sni: true,
            fp: true
        };
        var vmessUnknown = {};
        for (var vk in ssm) {
            if (!ssm.hasOwnProperty(vk)) continue;
            if (knownVmessJsonKeys[vk]) continue;
            if (ssm[vk] == null) continue;
            if (typeof ssm[vk] === 'object') continue;
            vmessUnknown[vk] = normalizeUnknownParamValueByKey(vk, String(ssm[vk]));
        }
        mergeUnknownParamsToOtherParameters(sid, vmessUnknown);

        return true;
    } catch (e) {
        // Try Xray VMessAEAD format
        try {
            var parsed = parseUrl('vmess://' + body);
            if (!parsed) return false;

            var query = parseQuery(parsed.search);
            var network = (query.type || 'tcp').toLowerCase();

            setFormValue(sid, 'type', 'vmess');
            if (network === 'ws') {
                setFormValue(sid, 'obfs_vmess', 'websocket');
            } else if (network === 'grpc') {
                setFormValue(sid, 'obfs_vmess', 'grpc');
            } else if (network === 'http') {
                setFormValue(sid, 'obfs_vmess', 'http');
            } else if (network === 'h2') {
                setFormValue(sid, 'obfs_vmess', 'h2');
            } else {
                setFormValue(sid, 'obfs_vmess', 'none');
            }

            setFormValue(sid, 'server', parsed.hostname);
            setFormValue(sid, 'port', parsed.port || '443');
            setFormValue(sid, 'uuid', decodeURIComponentSafe(parsed.username));
            setFormValue(sid, 'alterId', 0);
            setFormValue(sid, 'cipher', query.encryption || 'auto');

            var security = (query.security || '').toLowerCase();
            if (security === 'tls' || security === 'xtls' || security === 'reality') {
                setFormValue(sid, 'tls', 'true');
            }

            if (query.sni) {
                setFormValue(sid, 'servername', decodeURIComponentSafe(query.sni));
            }

            if (query.fp) {
                setFormValue(sid, 'client_fingerprint', decodeURIComponentSafe(query.fp));
            }

            if (network === 'ws') {
                setFormValue(sid, 'ws_path', decodeURIComponentSafe(query.path || '/'));
                if (query.host) {
                    setFormValue(sid, 'ws_headers', 'Host: ' + decodeURIComponentSafe(query.host));
                }
            } else if (network === 'grpc') {
                setFormValue(sid, 'grpc_service_name', decodeURIComponentSafe(query.serviceName || query.path || ''));
            } else if (network === 'http') {
                if (query.path) {
                    setFormValue(sid, 'http_path', decodeURIComponentSafe(query.path));
                }
            } else if (network === 'h2') {
                if (query.path) {
                    setFormValue(sid, 'h2_path', decodeURIComponentSafe(query.path));
                }
                if (query.host) {
                    setFormValue(sid, 'h2_host', decodeURIComponentSafe(query.host));
                }
            }

            if (query.allowInsecure === '1' || query.allowInsecure === 'true' || query.insecure === '1' || query.insecure === 'true') {
                setFormValue(sid, 'skip_cert_verify', 'true');
            }

            if (parsed.hash) {
                setFormValue(sid, 'name', decodeFragment(parsed.hash.substr(1)));
            }

            mergeUnknownParamsToOtherParameters(sid, collectUnknownQueryParams(query, {
                encryption: true,
                sni: true,
                fp: true,
                security: true,
                type: true,
                path: true,
                host: true,
                serviceName: true,
                allowInsecure: true,
                insecure: true
            }));

            return true;
        } catch (e2) {
            return false;
        }
    }
}

function parseVless(url, sid) {
    var parsed = parseUrl(url);
    if (!parsed) return false;

    var query = parseQuery(parsed.search);

    setFormValue(sid, 'type', 'vless');
    setFormValue(sid, 'server', parsed.hostname);
    setFormValue(sid, 'port', parsed.port || '443');
    setFormValue(sid, 'uuid', decodeURIComponentSafe(parsed.username));

    var network = (query.type || 'tcp').toLowerCase();
    if (network === 'ws') {
        setFormValue(sid, 'obfs_vless', 'ws');
    } else if (network === 'grpc') {
        setFormValue(sid, 'obfs_vless', 'grpc');
    } else if (network === 'xhttp') {
        setFormValue(sid, 'obfs_vless', 'xhttp');
    } else {
        setFormValue(sid, 'obfs_vless', 'tcp');
    }

    if (query.security) {
        if (query.security === 'tls' || query.security === 'xtls') {
            setFormValue(sid, 'tls', 'true');
            if (query.sni) {
                setFormValue(sid, 'servername', decodeURIComponent(query.sni));
            }
            if (query.security === 'xtls' && network === 'tcp') {
                setFormValue(sid, 'vless_flow', query.flow || 'xtls-rprx-direct');
            }
        } else if (query.security === 'reality') {
            setFormValue(sid, 'tls', 'true');
            if (query.sni) {
                setFormValue(sid, 'servername', decodeURIComponent(query.sni));
            }
            if ((network === 'tcp' || network === 'grpc') && (query.pbk || query['public-key'])) {
                setFormValue(sid, 'reality_public_key', query.pbk || query['public-key']);
            }
            if ((network === 'tcp' || network === 'grpc') && (query.sid || query['short-id'])) {
                setFormValue(sid, 'reality_short_id', query.sid || query['short-id']);
            }
        }
    }

    if (network === 'tcp' && query.encryption) {
        setFormValue(sid, 'vless_encryption', decodeURIComponentSafe(query.encryption));
    }

    if (query.fp) {
        setFormValue(sid, 'client_fingerprint', decodeURIComponentSafe(query.fp));
    }

    if (network === 'tcp' && query.flow) {
        setFormValue(sid, 'vless_flow', decodeURIComponentSafe(query.flow || 'xtls-rprx-direct'));
    }

    if (network === 'ws') {
        setFormValue(sid, 'ws_path', decodeURIComponent(query.path || '/'));
        if (query.host) {
            setFormValue(sid, 'ws_headers', 'Host: ' + decodeURIComponent(query.host));
        }
    } else if (network === 'grpc') {
        setFormValue(sid, 'grpc_service_name', decodeURIComponent(query.serviceName || query.path || ''));
    } else if (network === 'xhttp') {
        if (query.path) {
            setFormValue(sid, 'xhttp_opts_path', decodeURIComponent(query.path));
        }
        if (query.host) {
            setFormValue(sid, 'xhttp_opts_host', decodeURIComponent(query.host));
        }
    }

    if (parsed.hash) {
        setFormValue(sid, 'name', decodeFragment(parsed.hash.substr(1)));
    }

    var knownVlessQueryKeys = {
        security: true,
        sni: true,
        flow: true,
        type: true,
        path: true,
        host: true,
        serviceName: true,
        pbk: true,
        'public-key': true,
        sid: true,
        'short-id': true,
        fp: true
    };

    if (network === 'tcp') {
        knownVlessQueryKeys.encryption = true;
    }

    mergeUnknownParamsToOtherParameters(sid, collectUnknownQueryParams(query, knownVlessQueryKeys));

    return true;
}

function parseTrojan(url, sid) {
    var parsed = parseUrl(url);
    if (!parsed) return false;

    var query = parseQuery(parsed.search);

    setFormValue(sid, 'type', 'trojan');
    setFormValue(sid, 'server', parsed.hostname);
    setFormValue(sid, 'port', parsed.port || '443');
    setFormValue(sid, 'password', decodeURIComponentSafe(parsed.username));
    setFormValue(sid, 'obfs_trojan', 'none');

    if (query.sni) {
        setFormValue(sid, 'sni', decodeURIComponent(query.sni));
    }

    if (query.alpn) {
        // Handle ALPN - multiple values support, decode properly
        setFormValue(sid, 'alpn', decodeURIComponent(query.alpn));
    }

    if (query.pcs) {
        setFormValue(sid, 'fingerprint', decodeURIComponentSafe(query.pcs));
    }

    var network = (query.type || '').toLowerCase();
    if (network === 'ws') {
        setFormValue(sid, 'obfs_trojan', 'ws');
        setFormValue(sid, 'ws_path', decodeURIComponent(query.path || '/'));
        if (query.host) {
            setFormValue(sid, 'ws_headers', 'Host: ' + decodeURIComponent(query.host));
        }
    } else if (network === 'grpc') {
        setFormValue(sid, 'obfs_trojan', 'grpc');
        setFormValue(sid, 'grpc_service_name', decodeURIComponent(query.serviceName || ''));
    }

    if (query.allowInsecure === '1' || query.allowInsecure === 'true') {
        setFormValue(sid, 'skip_cert_verify', 'true');
    }

    if (parsed.hash) {
        setFormValue(sid, 'name', decodeFragment(parsed.hash.substr(1)));
    }

    mergeUnknownParamsToOtherParameters(sid, remapParamKeys(collectUnknownQueryParams(query, {
        sni: true,
        alpn: true,
        allowInsecure: true,
        type: true,
        path: true,
        host: true,
        serviceName: true,
        pcs: true
    }), {
        fp: 'client-fingerprint',
        serviceName: 'grpc-service-name'
    }));

    return true;
}

// hysteria/hysteria2 may carry a port list (example.com:123,5000-6000): the first entry
// is the node port, the rest are the hopping ports.
function applyHysteriaAuthorityPort(sid, authorityPort) {
    var parts = String(authorityPort || '').split(',');
    var basePort = parts[0] || '443';
    var hopPorts = parts.slice(1).join(',');

    if (basePort.indexOf('-') !== -1) {
        hopPorts = hopPorts ? basePort + ',' + hopPorts : basePort;
        basePort = basePort.split('-')[0];
    }

    setFormValue(sid, 'port', basePort);

    if (hopPorts) {
        setFormValue(sid, 'flag_port_hopping', '1');
        setFormValue(sid, 'ports', hopPorts);
    }
}

function parseHysteria(url, sid) {
    var parsed = parseUrl(url);
    if (!parsed) return false;

    var query = parseQuery(parsed.search);

    setFormValue(sid, 'type', 'hysteria');
    setFormValue(sid, 'server', parsed.hostname);
    applyHysteriaAuthorityPort(sid, parsed.port);

    if (query.auth) {
        setFormValue(sid, 'hysteria_auth_str', decodeURIComponentSafe(query.auth));
    }

    if (query.protocol) {
        setFormValue(sid, 'flag_transport', '1');
        setFormValue(sid, 'hysteria_protocol', query.protocol);
    }

    if (query.ports) {
        setFormValue(sid, 'flag_port_hopping', '1');
        setFormValue(sid, 'ports', decodeURIComponentSafe(query.ports));
    }

    if (query['hop-interval']) {
        setFormValue(sid, 'flag_port_hopping', '1');
        setFormValue(sid, 'flag_transport', '1');
        setFormValue(sid, 'hop_interval', decodeURIComponentSafe(query['hop-interval']));
    }

    if (query.up || query.upmbps) {
        var upSpeed = decodeURIComponentSafe(query.up || query.upmbps);
        upSpeed = upSpeed.replace(/[^0-9]/g, '');
        setFormValue(sid, 'hysteria_up', upSpeed);
    }

    if (query.down || query.downmbps) {
        var downSpeed = decodeURIComponentSafe(query.down || query.downmbps);
        downSpeed = downSpeed.replace(/[^0-9]/g, '');
        setFormValue(sid, 'hysteria_down', downSpeed);
    }

    if (query.obfs || query.obfsParam) {
        setFormValue(sid, 'hysteria_obfs', decodeURIComponentSafe(query.obfs || query.obfsParam));
    }

    if (query.peer || query.sni) {
        setFormValue(sid, 'sni', decodeURIComponentSafe(query.peer || query.sni));
    }

    if (query.alpn) {
        setFormValue(sid, 'alpn', decodeURIComponentSafe(query.alpn));
    }

    if (query.insecure === '1' || query.insecure === 'true') {
        setFormValue(sid, 'skip_cert_verify', 'true');
    }

    if (query['recv-window-conn']) {
        setFormValue(sid, 'flag_quicparam', '1');
        setFormValue(sid, 'recv_window_conn', decodeURIComponentSafe(query['recv-window-conn']));
    }

    if (query['recv-window']) {
        setFormValue(sid, 'flag_quicparam', '1');
        setFormValue(sid, 'recv_window', decodeURIComponentSafe(query['recv-window']));
    }

    if (query['disable-mtu-discovery']) {
        setFormValue(sid, 'flag_quicparam', '1');
        setFormValue(sid, 'disable_mtu_discovery', (query['disable-mtu-discovery'] === '1' || query['disable-mtu-discovery'] === 'true') ? 'true' : 'false');
    }

    if (query['fast-open']) {
        setFormValue(sid, 'flag_quicparam', '1');
        setFormValue(sid, 'fast_open', (query['fast-open'] === '1' || query['fast-open'] === 'true') ? 'true' : 'false');
    }

    if (query.fingerprint) {
        setFormValue(sid, 'fingerprint', decodeURIComponentSafe(query.fingerprint));
    }

    if (parsed.hash) {
        setFormValue(sid, 'name', decodeFragment(parsed.hash.substr(1)));
    }

    mergeUnknownParamsToOtherParameters(sid, collectUnknownQueryParams(query, {
        auth: true,
        protocol: true,
        up: true,
        upmbps: true,
        down: true,
        downmbps: true,
        obfs: true,
        obfsParam: true,
        peer: true,
        sni: true,
        alpn: true,
        insecure: true,
        ports: true,
        'hop-interval': true,
        'recv-window-conn': true,
        'recv-window': true,
        'disable-mtu-discovery': true,
        'fast-open': true,
        fingerprint: true
    }));

    return true;
}

function parseHysteria2(url, sid) {
    var parsed = parseUrl(url);
    if (!parsed) return false;

    var query = parseQuery(parsed.search);

    setFormValue(sid, 'type', 'hysteria2');
    setFormValue(sid, 'server', parsed.hostname);
    applyHysteriaAuthorityPort(sid, parsed.port);

    if (parsed.username) {
        setFormValue(sid, 'password', decodeURIComponentSafe(parsed.username));
    }

    if (query.obfs) {
        setFormValue(sid, 'hysteria_obfs', decodeURIComponentSafe(query.obfs));
    }

    if (query['obfs-password']) {
        setFormValue(sid, 'obfs_password', decodeURIComponentSafe(query['obfs-password']));
    }

    if (query.up) {
        setFormValue(sid, 'hysteria_up', decodeURIComponentSafe(query.up));
    }

    if (query.down) {
        setFormValue(sid, 'hysteria_down', decodeURIComponentSafe(query.down));
    }

    if (query.sni) {
        setFormValue(sid, 'sni', decodeURIComponentSafe(query.sni));
    }

    if (query.alpn) {
        setFormValue(sid, 'alpn', decodeURIComponentSafe(query.alpn));
    }

    if (query.insecure === '1' || query.insecure === 'true') {
        setFormValue(sid, 'skip_cert_verify', 'true');
    }

    if (query.pinSHA256) {
        setFormValue(sid, 'fingerprint', decodeURIComponentSafe(query.pinSHA256));
    }

    if (query.ports) {
        setFormValue(sid, 'flag_port_hopping', '1');
        setFormValue(sid, 'ports', decodeURIComponentSafe(query.ports));
    }

    if (query['hop-interval']) {
        setFormValue(sid, 'flag_port_hopping', '1');
        setFormValue(sid, 'hop_interval', decodeURIComponentSafe(query['hop-interval']));
    }

    if (query['initial-stream-receive-window']) {
        setFormValue(sid, 'flag_quicparam', '1');
        setFormValue(sid, 'initial_stream_receive_window', decodeURIComponentSafe(query['initial-stream-receive-window']));
    }

    if (query['max-stream-receive-window']) {
        setFormValue(sid, 'flag_quicparam', '1');
        setFormValue(sid, 'max_stream_receive_window', decodeURIComponentSafe(query['max-stream-receive-window']));
    }

    if (query['initial-connection-receive-window']) {
        setFormValue(sid, 'flag_quicparam', '1');
        setFormValue(sid, 'initial_connection_receive_window', decodeURIComponentSafe(query['initial-connection-receive-window']));
    }

    if (query['max-connection-receive-window']) {
        setFormValue(sid, 'flag_quicparam', '1');
        setFormValue(sid, 'max_connection_receive_window', decodeURIComponentSafe(query['max-connection-receive-window']));
    }

    if (parsed.hash) {
        setFormValue(sid, 'name', decodeFragment(parsed.hash.substr(1)));
    }

    mergeUnknownParamsToOtherParameters(sid, collectUnknownQueryParams(query, {
        obfs: true,
        'obfs-password': true,
        up: true,
        down: true,
        sni: true,
        alpn: true,
        insecure: true,
        pinSHA256: true,
        protocol: true,
        ports: true,
        'hop-interval': true,
        'initial-stream-receive-window': true,
        'max-stream-receive-window': true,
        'initial-connection-receive-window': true,
        'max-connection-receive-window': true
    }));

    return true;
}

function parseTuic(url, sid) {
    var parsed = parseUrl(url);
    if (!parsed) return false;

    var query = parseQuery(parsed.search);

    setFormValue(sid, 'type', 'tuic');
    setFormValue(sid, 'server', parsed.hostname);
    setFormValue(sid, 'port', parsed.port || '443');

    // Check if it's v5 (has password) or v4 (token only)
    if (parsed.password) {
        setFormValue(sid, 'uuid', decodeURIComponentSafe(parsed.username));
        setFormValue(sid, 'password', decodeURIComponentSafe(parsed.password));
    } else {
        setFormValue(sid, 'token', decodeURIComponentSafe(parsed.username));
    }

    if (query.congestion_control || query['congestion-controller']) {
        setFormValue(sid, 'congestion_controller', decodeURIComponentSafe(query.congestion_control || query['congestion-controller']));
    }

    if (query.alpn) {
        setFormValue(sid, 'alpn', decodeURIComponent(query.alpn));
    }

    if (query.sni) {
        setFormValue(sid, 'sni', decodeURIComponent(query.sni));
    }

    if (query.disable_sni === '1' || query.disable_sni === 'true') {
        setFormValue(sid, 'disable_sni', 'true');
    }

    if (query.udp_relay_mode) {
        setFormValue(sid, 'udp_relay_mode', decodeURIComponent(query.udp_relay_mode));
    }

    if (query.reduce_rtt === '1' || query.reduce_rtt === 'true') {
        setFormValue(sid, 'reduce_rtt', 'true');
    }

    if (query['heartbeat-interval']) {
        setFormValue(sid, 'heartbeat_interval', decodeURIComponentSafe(query['heartbeat-interval']));
    }

    if (query['request-timeout']) {
        setFormValue(sid, 'request_timeout', decodeURIComponentSafe(query['request-timeout']));
    }

    if (query['max-udp-relay-packet-size']) {
        setFormValue(sid, 'max_udp_relay_packet_size', decodeURIComponentSafe(query['max-udp-relay-packet-size']));
    }

    if (query['max-open-streams']) {
        setFormValue(sid, 'max_open_streams', decodeURIComponentSafe(query['max-open-streams']));
    }

    if (query['fast-open']) {
        setFormValue(sid, 'fast_open', query['fast-open'] === '1' || query['fast-open'] === 'true' ? 'true' : 'false');
    }

    if (query['skip-cert-verify']) {
        setFormValue(sid, 'skip_cert_verify', query['skip-cert-verify'] === '1' || query['skip-cert-verify'] === 'true' ? 'true' : 'false');
    }

    if (parsed.hash) {
        setFormValue(sid, 'name', decodeFragment(parsed.hash.substr(1)));
    }

    mergeUnknownParamsToOtherParameters(sid, collectUnknownQueryParams(query, {
        congestion_control: true,
        'congestion-controller': true,
        alpn: true,
        sni: true,
        disable_sni: true,
        udp_relay_mode: true,
        reduce_rtt: true,
        'heartbeat-interval': true,
        'request-timeout': true,
        'max-udp-relay-packet-size': true,
        'max-open-streams': true,
        'fast-open': true,
        'skip-cert-verify': true
    }));

    return true;
}

function parseSocks(url, sid) {
    var parsed = parseUrl(url);
    if (!parsed) return false;

    var query = parseQuery(parsed.search);

    setFormValue(sid, 'type', 'socks5');
    setFormValue(sid, 'server', parsed.hostname);
    setFormValue(sid, 'port', parsed.port || '1080');

    if (parsed.username) {
        setFormValue(sid, 'username', decodeURIComponentSafe(parsed.username));
        if (parsed.password) {
            setFormValue(sid, 'password', decodeURIComponentSafe(parsed.password));
        }
    }

    if (parsed.hash) {
        setFormValue(sid, 'name', decodeFragment(parsed.hash.substr(1)));
    } else {
        setFormValue(sid, 'name', parsed.hostname + ':' + parsed.port);
    }

    mergeUnknownParamsToOtherParameters(sid, collectUnknownQueryParams(query, {}));

    return true;
}

function parseHttp(url, sid) {
    var parsed = parseUrl(url);
    if (!parsed) return false;

    var query = parseQuery(parsed.search);

    setFormValue(sid, 'type', 'http');
    setFormValue(sid, 'server', parsed.hostname);
    setFormValue(sid, 'port', parsed.port || (parsed.protocol === 'https:' ? '443' : '80'));

    if (parsed.protocol === 'https:') {
        setFormValue(sid, 'tls', 'true');
    }

    if (parsed.username) {
        setFormValue(sid, 'username', decodeURIComponentSafe(parsed.username));
        if (parsed.password) {
            setFormValue(sid, 'password', decodeURIComponentSafe(parsed.password));
        }
    }

    if (parsed.hash) {
        setFormValue(sid, 'name', decodeFragment(parsed.hash.substr(1)));
    } else {
        setFormValue(sid, 'name', parsed.hostname + ':' + parsed.port);
    }

    mergeUnknownParamsToOtherParameters(sid, collectUnknownQueryParams(query, {}));

    return true;
}

function parseAnyTLS(url, sid) {
    var parsed = parseUrl(url);
    if (!parsed) return false;

    var query = parseQuery(parsed.search);

    setFormValue(sid, 'type', 'anytls');
    setFormValue(sid, 'server', parsed.hostname);
    setFormValue(sid, 'port', parsed.port || '443');
    setFormValue(sid, 'password', decodeURIComponentSafe(parsed.password || parsed.username));

    if (query.sni) {
        setFormValue(sid, 'sni', decodeURIComponentSafe(query.sni));
    }

    if (query.alpn) {
        setFormValue(sid, 'alpn', decodeURIComponentSafe(query.alpn));
    }

    if (query.insecure === '1' || query.insecure === 'true') {
        setFormValue(sid, 'skip_cert_verify', 'true');
    }

    if (query['client-fingerprint'] || query.fp) {
        setFormValue(sid, 'client_fingerprint', decodeURIComponentSafe(query['client-fingerprint'] || query.fp));
    }

    if (query.udp) {
        setFormValue(sid, 'udp', query.udp === '1' || query.udp === 'true' ? 'true' : 'false');
    }

    if (query['idle-session-check-interval']) {
        setFormValue(sid, 'idle_session_check_interval', decodeURIComponentSafe(query['idle-session-check-interval']));
    }

    if (query['idle-session-timeout']) {
        setFormValue(sid, 'idle_session_timeout', decodeURIComponentSafe(query['idle-session-timeout']));
    }

    if (query['min-idle-session']) {
        setFormValue(sid, 'min_idle_session', decodeURIComponentSafe(query['min-idle-session']));
    }

    if (parsed.hash) {
        setFormValue(sid, 'name', decodeFragment(parsed.hash.substr(1)));
    } else {
        setFormValue(sid, 'name', parsed.hostname + ':' + parsed.port);
    }

    var unknownParams = remapParamKeys(collectUnknownQueryParams(query, {
        sni: true,
        insecure: true,
        alpn: true,
        'client-fingerprint': true,
        fp: true,
        udp: true,
        'idle-session-check-interval': true,
        'idle-session-timeout': true,
        'min-idle-session': true
    }), {
        hpkp: 'fingerprint',
        fp: 'client-fingerprint'
    });

    if (parsed.username) {
        unknownParams.username = decodeURIComponentSafe(parsed.username);
    }

    mergeUnknownParamsToOtherParameters(sid, unknownParams);

    return true;
}

function parseMieru(url, sid) {
    var parsed = parseUrl(url);
    if (!parsed) return false;

    var query = parseQuery(parsed.search);

    setFormValue(sid, 'type', 'mieru');
    setFormValue(sid, 'server', parsed.hostname);
    setFormValue(sid, 'username', decodeURIComponentSafe(parsed.username));
    setFormValue(sid, 'password', decodeURIComponentSafe(parsed.password));

    var ports = query.port ? decodeURIComponentSafe(query.port).split(',') : [];
    var protocols = query.protocol ? decodeURIComponentSafe(query.protocol).split(',') : [];
    if (ports.length > 0) {
        if (ports.length === 1) {
            if (ports[0].indexOf('-') !== -1) {
                setFormValue(sid, 'port_range', ports[0]);
            } else {
                setFormValue(sid, 'port', ports[0]);
            }
        } else {
            setFormValue(sid, 'port_range', ports.join(','));
        }
    }

    if (protocols.length > 0 && protocols[0]) {
        setFormValue(sid, 'transport', protocols[0]);
    }

    if (query.multiplexing) {
        setFormValue(sid, 'multiplexing', decodeURIComponentSafe(query.multiplexing));
    }

    if (parsed.hash) {
        setFormValue(sid, 'name', decodeFragment(parsed.hash.substr(1)));
    }

    mergeUnknownParamsToOtherParameters(sid, collectUnknownQueryParams(query, {
        port: true,
        protocol: true,
        multiplexing: true
    }));

    return true;
}
